<?php include 'header.php' ?>



    <!-- banner -->
    <!-- <div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slideshow="ratio: 7:3; animation: push">

<div class="uk-slideshow-items">
    <div>
        <img src="images/1.jpeg" alt="" uk-cover>
    </div>
    <div>
        <img src="images/2.jpeg" alt="" uk-cover>
    </div>
    <div>
        <img src="images/3.jpeg" alt="" uk-cover>
    </div>
</div>

<a class="uk-position-center-left uk-position-small uk-hidden-hover" href uk-slidenav-previous uk-slideshow-item="previous"></a>
<a class="uk-position-center-right uk-position-small uk-hidden-hover" href uk-slidenav-next uk-slideshow-item="next"></a>

</div> -->


<div class="container-fluid "   id="home">
    <div class="row d-flex align-items-center " style="min-height: 20vh;">
  
        <div class="col-md-6  text-center" >
        <h1 class="font g-t" style="text-shadow:5px 5px 15px gray;font-weight:900; " >
    
    <?php echo $cname; ?>
</h1>
        </div>
        <div class="col-6 h-100 p-5 lg text-white font" style="min-height: 90vh;">
            <h1 class="text-white-50 font">
                How to Open An Computer Academy ?
            </h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Explicabo voluptates possimus impedit nihil nostrum blanditiis perspiciatis architecto quam est, totam, assumenda facilis voluptatem in doloremque reprehenderit consequuntur at ratione voluptate, dolore soluta! Ducimus tempora corrupti impedit eaque facere quia dignissimos iure, possimus similique vero atque unde. Omnis, unde, rem necessitatibus fugit architecto provident dignissimos laborum, dolore velit sequi minima eaque dicta. Accusamus praesentium architecto iste nesciunt eius consequatur vitae eos. Atque hic temporibus doloremque esse qui voluptate. Itaque tempore veniam, sed corporis possimus vero perferendis earum cum voluptate dicta quod, fugiat exercitationem. Eveniet sunt quas officia repellendus? Hic, error iure.</p>
            <p id="lat"></p> 
    <p id="lng"></p>
        </div>
    </div>
</div>


<!-- about us -->

<div class="container-fluid g " id="about">
    <div class="row">
        <!-- <div class="col-md-2"></div> -->
        <div class="col-md-12 p-5" style="color:white;border-radius:30px 0px 0px 30px">
            <header class="big ">&nbsp; About Us</header>
            <p class="pb-3">

                Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet quis illum, nemo ab, iste omnis, nulla dolor quidem maxime qui unde quos quam a culpa sunt ex porro aliquid placeat. Vitae eum exercitationem eligendi quas iste aperiam sed maiores aspernatur sapiente, similique omnis voluptates doloribus animi sunt tempora labore ipsam doloremque non ex molestiae est eaque! Explicabo nisi minima neque. Ullam repellat alias, adipisci hic aspernatur vitae animi reiciendis. Nesciunt tempora itaque harum, aut nostrum cumque, non optio impedit cum excepturi quae perspiciatis neque laudantium voluptas dicta explicabo! Excepturi, eius repellendus quibusdam atque fugiat esse laborum quod doloribus consectetur similique.
            </p>
            <a href="about.php" class="btn btn-success g float-end">KNOW MORE ABOUT US </a>
            </div>
    </div>
</div>

<!-- dca -->
<div class="container font " style="margin-top: 300px;" id="cources">
    <div class="row" style="min-height: 100vh;">
        
        <!-- <div class="col-md-2"></div> -->
        <div class="col-md-5 h-100  ">
            <p>
            It sounds like you're asking about ADCA. Could you please clarify which ADCA you're referring to? ADCA could refer to different things depending on the context. For example:

            </p>
            <ol>
                <li>
                **ADCA (Advanced Data Collection and Analysis)**: A term used in various fields to describe sophisticated methods of collecting and analyzing data.
                </li>
                <li>
                **ADCA (Airline Data Communication Association)**: An organization focusing on data communication in the airline industry.
                    </li>
                   <li>
                   **ADCA (Association of Data Communication and Analysis)**: A professional association or organization focused on data communication and analysis.
                </li> 
                <li>
                **ADCA (American Digital Communications Association)**: An organization related to digital communications in the U.S.

                </li>
                
            </ol>

<p>
If you provide more details, I can give you a more specific answer!
            </p>
        </div>
        <div class="col-md-5" >
            <p style="font-size: 255px;transform:rotate(90deg);" class="g-t">MUSIC</p>
        </div>
    </div> 
</div>
<!-- adca -->
<div class="container font " style="margin-top: 100px;">
    <div class="row" style="min-height: 100vh;">
        <div class="col-md-5" >
            <p style="font-size: 255px;transform:rotate(270deg);color:#d17b30">ADCA</p>
        </div>
        <!-- <div class="col-md-2"></div> -->
        <div class="col-md-5 h-100    ">
            <p>
            It sounds like you're asking about ADCA. Could you please clarify which ADCA you're referring to? ADCA could refer to different things depending on the context. For example:

            </p>
            <ol>
                <li>
                **ADCA (Advanced Data Collection and Analysis)**: A term used in various fields to describe sophisticated methods of collecting and analyzing data.
                </li>
                <li>
                **ADCA (Airline Data Communication Association)**: An organization focusing on data communication in the airline industry.
                    </li>
                   <li>
                   **ADCA (Association of Data Communication and Analysis)**: A professional association or organization focused on data communication and analysis.
                </li> 
                <li>
                **ADCA (American Digital Communications Association)**: An organization related to digital communications in the U.S.

                </li>
                
            </ol>

<p>
If you provide more details, I can give you a more specific answer!
            </p>
        </div>
    </div> 
</div>

<!-- programming -->
<div class="container font " style="margin-top: 0px;">
    <div class="row" style="min-height: 100vh;">
        
        <!-- <div class="col-md-2"></div> -->
        <div class="col-md-4 h-100  ">
            <p>
            It sounds like you're asking about ADCA. Could you please clarify which ADCA you're referring to? ADCA could refer to different things depending on the context. For example:

            </p>
            <ol>
                <li>
                **ADCA (Advanced Data Collection and Analysis)**: A term used in various fields to describe sophisticated methods of collecting and analyzing data.
                </li>
                <li>
                **ADCA (Airline Data Communication Association)**: An organization focusing on data communication in the airline industry.
                    </li>
                   <li>
                   **ADCA (Association of Data Communication and Analysis)**: A professional association or organization focused on data communication and analysis.
                </li> 
                <li>
                **ADCA (American Digital Communications Association)**: An organization related to digital communications in the U.S.

                </li>
                
            </ol>

<p>
If you provide more details, I can give you a more specific answer!
            </p>
        </div>
        <div class="col-md-1"></div>
        <div class="col-md-6" >
            <p class="text-wrap" style="font-size: 255px;transform:rotate(0deg);color:#01789e;margin-top:-150px">PRO</p>
            <p class="text-wrap" style="font-size: 255px;transform:rotate(0deg);color:#01789e;margin-top:-150px">GRAM</p>
            <p class="text-wrap" style="font-size: 255px;transform:rotate(0deg);color:#01789e;margin-top:-150px">MING</p>
        </div>
    </div> 
</div>



<!-- certificate -->
 <br><br><br>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- <p class="text-center" style="font-size: 100px;transform:rotate(0deg);color:#c3a9ff;margin-bottom:-100px;">CERTIFICATE</p> -->
            <p class="text-center" style="font-size: 110px;transform:rotate(0deg);color:#c3a9ff;margin-bottom:-120px;">CERTIFICATE</p>
            <p class="text-center" style="font-size: 180px;transform:rotate(0deg);color:#c3a9ff;margin-bottom:-150px;">CERTIFICATE</p>
            <p class="text-center" style="font-size: 255px;transform:rotate(0deg);color:#01789e;margin-top:00px;">CERTIFICATE</p>
            <p class="text-center" style="font-size: 180px;transform:rotate(0deg);color:#d17b30;margin-top:-150px;">CERTIFICATE</p>
            <p class="text-center" style="font-size: 110px;transform:rotate(0deg);color:#d17b30;margin-top:-120px;">CERTIFICATE</p>
            <!-- <p class="text-center" style="font-size: 100px;transform:rotate(0deg);color:#d17b30;margin-top:-100px;">CERTIFICATE</p> -->
            
        </div>
    </div>
</div>



<!-- slide -->
 <br><br>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-10 p-5" style="background-color:#c3a9ff;color:white;border-radius:0px 30px 30px 0px">
            
        <header class="big  mb-3">&nbsp; Our Top Institute</header>


        <div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slider>

<div class="uk-slider-items uk-child-width-1-2 uk-child-width-1-3@m uk-grid">
    <div>
        <div class="uk-panel">
            <img src="images/1.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>1</h1></div>
        </div>
    </div>
    <div>
        <div class="uk-panel">
            <img src="images/2.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>2</h1></div>
        </div>
    </div>
    <div>
        <div class="uk-panel">
            <img src="images/3.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>3</h1></div>
        </div>
    </div>
    <div>
        <div class="uk-panel">
            <img src="images/1.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>4</h1></div>
        </div>
    </div>
    <div>
        <div class="uk-panel">
            <img src="images/2.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>5</h1></div>
        </div>
    </div>
    <div>
        <div class="uk-panel">
            <img src="images/3.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>6</h1></div>
        </div>
    </div>
    <div>
        <div class="uk-panel">
            <img src="images/1.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>7</h1></div>
        </div>
    </div>
    <div>
        <div class="uk-panel">
            <img src="images/2.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>8</h1></div>
        </div>
    </div>
    <div>
        <div class="uk-panel">
            <img src="images/3.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>9</h1></div>
        </div>
    </div>
    <div>
        <div class="uk-panel">
            <img src="images/1.jpeg" width="400" height="600" alt="">
            <div class="uk-position-center uk-panel"><h1>10</h1></div>
        </div>
    </div>
</div>

<a class="uk-position-center-left uk-position-small uk-hidden-hover" href uk-slidenav-previous uk-slider-item="previous"></a>
<a class="uk-position-center-right uk-position-small uk-hidden-hover" href uk-slidenav-next uk-slider-item="next"></a>

</div>


        </div>
        <div class="col-md-2"></div>
    </div>
</div>







<!-- certificate picture -->

<div class="container-fluid font " style="margin-top:50px;background-image:url(images/bg.png);background-attachment:fixed;background-size:cover">
    <div class="row p-5" style="min-height: 100vh;">
        
        <!-- <div class="col-md-2"></div> -->
        <div class="col-md-4 h-100  ">
            <header class="big ">&nbsp;&nbsp;Why Choose Us ?</header>
           
            <ol>
                <li>
                **ADCA (Advanced Data Collection and Analysis)**: A term used in various fields to describe sophisticated methods of collecting and analyzing data.
                </li>
                <li>
                **ADCA (Airline Data Communication Association)**: An organization focusing on data communication in the airline industry.
                    </li>
                   <li>
                   **ADCA (Association of Data Communication and Analysis)**: A professional association or organization focused on data communication and analysis.
                </li> 
                <li>
                **ADCA (American Digital Communications Association)**: An organization related to digital communications in the U.S.

                </li>
                <li>
                **ADCA (American Digital Communications Association)**: An organization related to digital communications in the U.S.

                </li>
                <li>
                **ADCA (American Digital Communications Association)**: An organization related to digital communications in the U.S.

                </li>
                <li>
                **ADCA (American Digital Communications Association)**: An organization related to digital communications in the U.S.

                </li>
                
            </ol>


        </div>
        <div class="col-md-1"></div>
        <div class="col-md-7 d-flex justify-content-center align-items-center" >
           <img src="images/ce.jpg" width="120%" alt="" class="shadow-lg">
        </div>
    </div> 
<!-- </div> -->

<!-- our certificate -->
 <!-- <br><br><br>
<div class="container"> -->
    <div class="row d-flex justify-content-center">
        
        <div class="col-md-8 " >
            <header class="big mb-5">&nbsp; Our Certificate</header>
        <div uk-slider class="p-4 shadow-lg bg-white" style="border: 5px dashed #01789e;border-radius:20px">

<div class="uk-slider-items uk-child-width-1-2 uk-child-width-1-3@s uk-child-width-1-4@m uk-light">
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c1.jpg" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">1</h1></div>
    </div>
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c2.png" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">2</h1></div>
    </div>
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c3.png" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">3</h1></div>
    </div>
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c4.png" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">4</h1></div>
    </div>
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c1.jpg" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">5</h1></div>
    </div>
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c2.png" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">6</h1></div>
    </div>
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c3.png" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">7</h1></div>
    </div>
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c4.png" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">8</h1></div>
    </div>
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c1.jpg" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">9</h1></div>
    </div>
    <div class="uk-transition-toggle" tabindex="0">
        <img src="images/c2.png" width="400" height="600" alt="">
        <div class="uk-position-center uk-panel"><h1 class="uk-transition-slide-bottom-small">10</h1></div>
    </div>
</div>

<ul class="uk-slider-nav uk-dotnav uk-flex-center uk-margin"></ul>

</div>
        </div>
    </div>
</div>

<?php include "footer.php" ?>