<?php
include 'config.php';
$phone = $_POST['phone_no'];
$sql = "SELECT phone FROM institute WHERE phone = {$phone}"; 
// echo $sql;

$result = mysqli_query($conn,$sql);
echo mysqli_num_rows($result);



?>