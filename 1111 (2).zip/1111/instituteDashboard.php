<?php
include "config.php";
include "headerInstitute.php";




if(isset($_GET['success'])){
    if($_GET['success'] == 'true' ){
        include 'ani.php';
    }
}
?>


<?php 
        if(isset($_GET['submit']) == "trueIE"){
            echo " <script>
UIkit.notification('Updated Successfully ! Update Will Apply After Re-Login !',{pos: 'top-center',status: 'success'});
        </script>";
        }

        ?>



<div class="container">
    <div class="row">
        <div class="col-md-4 border text-center lg text-white fs-1">
            <label for="" class="fs-6">TOTAL NO. OF STUDENT </label><br>
            <?php 
            $num = 0;
            $sql1 = "SELECT id FROM newStudent WHERE institute = {$_SESSION["id"]}";
            $result1 = mysqli_query($conn,$sql1);
            while($row = mysqli_fetch_assoc($result1)){
                $num = $num + 1;
            }
            echo "<p>".$num."</p>";
            ?>
        </div>
        <div class="col-md-4 border text-center g text-white fs-1">
            <label for="" class="fs-6">TOTAL CERTIFICATE ISSUED </label><br>
            <?php 
            $num = 0;
            $sql2 = "SELECT id FROM certificate WHERE institute = {$_SESSION["id"]}";
            $result2 = mysqli_query($conn,$sql2);
            while($row = mysqli_fetch_assoc($result2)){
                $num = $num + 1;
            }
            echo "<p>".$num."</p>";
            ?>
        </div>
        <div class="col-md-4 border text-center lg text-white fs-1">
            <label for="" class="fs-6">TOTAL REMAINING CERTIFICATE TO ISSUE  </label><br>
            <?php 
            $num = 0;
            $sql1 = "SELECT id FROM newStudent WHERE institute = {$_SESSION["id"]} AND payment = 0";
            $result1 = mysqli_query($conn,$sql1);
            while($row = mysqli_fetch_assoc($result1)){
                $num = $num + 1;
            }
            echo "<p>".$num."</p>";
            ?>
        </div>
        <div class="col-md-12 mt-2 border text-center g text-white fs-1">
            <label for="" class="fs-6">AVERAGE PERCENTAGE OF YOUR CENTER : </label><br>
            <?php 
            $num = 0;
            $per = 0;
            $sql2 = "SELECT id,percentage FROM certificate WHERE institute = {$_SESSION["id"]}";
            $result2 = mysqli_query($conn,$sql2);
            if(mysqli_num_rows($result2) > 0){

           
            while($row = mysqli_fetch_assoc($result2)){
                $num = $num + 1;
                $per = $per + $row['percentage'];
            }
            $round = $per/$num;
            echo "<p>".round($round, 2)." %</p>";
        }
            // echo "<p>".$num."</p>";
            ?>
        </div>
        <div class="col-md-6 mt-2 p-5 border text-center lg text-white fs-1">
            <label for="" class="fs-6">AVERAGE DURATION OF YOUR CENTER : </label><br>
            <?php 
            $num = 0;
            $per = 0;
            $sql2 = "SELECT id,duration FROM certificate WHERE institute = {$_SESSION["id"]}";
            $result2 = mysqli_query($conn,$sql2);
            if(mysqli_num_rows($result2) > 0){

            while($row = mysqli_fetch_assoc($result2)){
                $num = $num + 1;
                $per = $per + $row['duration'];
            }
            $round1 = $per/$num;
            echo "<p>".round($round1)." Months</p>";
            }
            // echo "<p>".$num."</p>";
            ?>
        </div>
        <div class="col-md-6 mt-2 p-5 border text-start g text-white fs-3">
            <label for="" class="fs-6">YOUR HIGHEST ENROLLMENT SKILL IS: </label><br>
            <?php 
            $num = 1;
            $per = 0;
            $sql2 = "SELECT subSkill ,subSkillName,COUNT(subSkill) as num FROM certificate left join subskill on subskill.id = certificate.subskill WHERE institute = {$_SESSION["id"]} group by subskill";
            // $sql2 = "SELECT course,COUNT(course) AS C FROM newStudent WHERE institute = {$_SESSION["id"]} GROUP BY course ";
            // $sql2 = "SELECT MAX(count) FROM(SELECT course,COUNT(course) AS count FROM newStudent WHERE institute = {$_SESSION["id"]} GROUP BY course) ";
            $result2 = mysqli_query($conn,$sql2);
            while($row = mysqli_fetch_assoc($result2)){
                // $num = $num + 1;
                // $per = $per + $row['duration'];
                echo "<p>".$num.'-'.$row['subSkillName']." </p> ";
                $num++;


               
            }
            // echo "<p>".$num."</p>";
            ?>
        </div>
        <div class="col-md-4">
 
        </div>
        <div class="col-md-4"></div>
    </div>
</div>
<?php include "instituteFooter.php" ?>