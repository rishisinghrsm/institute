<?php include "headerInstitute.php";


?>
<?php include 'qr/phpqrcode/qrlib.php';  

// date_default_timezone_set('Asia/Kolkata');
// $date = date("l jS \of F Y h:i:s A");
// // $date = date("dmy ");
// echo $date;
// // $t = time();
// $t = date_default_timezone_get();
// $text = "Dhananjay ISngh"; 
// // $pixel_Size=30;
// $pixel_Size = 10; 
// $frame_Size = 10; 
// $path = 'qr/generatedQr/ ';

// $file = $path.uniqid().".png"; 
// // QR Code generation using png() 
// // When this function has only the 
// // text parameter it directly 
// // outputs QR in the browser 
// QRcode::png($text,$file, $pixel_Size, $frame_Size); 
// echo "<center><img src='".$file."'></center>";

?>





<div class="container">
    <form action="newStudentSubmit.php" method="post" enctype="multipart/form-data">
        <div class="row lg p-5 mt-5">
        <p class="fs-3 text-white border-bottom " style="text-shadow: 4px 4px 10px black;">ADD NEW STUDENT</p>
        <div class="col-4">
    <label class=" text-white mt-4">&nbsp; Name</label>
    <input type="text" name="name" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Name !">
    </div>
    <div class="col-4">
    <label class=" text-white mt-4">&nbsp;Passport Size Photo</label>
    <input type="file" accept="image/jpeg,image/png,image/jpg,image/PNG,image/JPEG,image/JPG" name="img1" id="file" class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Name !">
</div>
<div class="col-4">
        <label class=" text-white mt-4">&nbsp;Photo Preview</label><br>
        <img src="" alt="" id="file-preview" style="max-width: 180px;max-height:220px;border:2px solid white;min-width:180px;min-height:220px">
    </div>
    <script type="text/javascript">
                        $('#file').bind('change', function() {
                            // alert('Hi');
                            if (this.files[0].size < 300000) {



                                const input = document.getElementById('file');
                                const previewPhoto = () => {
                                    const file = input.files;
                                    if (file) {
                                        const fileReader = new FileReader();
                                        const preview = document.getElementById('file-preview');
                                        fileReader.onload = function(event) {
                                            preview.setAttribute('src', event.target.result);
                                        }
                                        fileReader.readAsDataURL(file[0]);
                                        $('#submit').css('display', 'inline');
                                    }
                                }
                                input.addEventListener("focusout", previewPhoto);
                                document.getElementById('size').innerHTML =
                                    '<b>' + file + '</b> KB';
                            } else {

                                alert('This file size is more then 300KB ! Please select less then 300KB !  ');
                                $('#submit').css('display', 'none');


                            }
                        });
                    </script>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Father's Name</label>
<input type="text" name="fname" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Father's Name !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Mother's Name</label>
                <input type="text" name="mname" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Mother's Name !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Phone Number</label>
<input type="number" name="phone" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Phone Number !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Aadhar Number</label>
<input type="text" name="aadhar" id=" " maxlength="12" class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Aadhar Number !">
</div>
<div class="col-4">

<label class=" text-white mt-4">&nbsp; Email</label>
                <input type="email" name="email" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Email !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Gender</label>
                <select name="gender" id="" class="form-control w-75">
                    <option value="0" selected disabled>Select</option>
                    <option value="m">Male</option>
                    <option value="f">Female</option>
                </select>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Address</label>
<input type="text" name="address" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Address !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Pincode</label>
<input type="text" name="pincode" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Pincode !">
</div>
<div class="col-4">
    <label class=" text-white mt-4">&nbsp; Currently Studing In ?</label>
    <select name="" id=" " class="form-control w-75 mt-2 bg-transparent">
        <option value="SELECT*" disabled selected>SELECT*</option>
    <option value="Class 1-9">Class 1-9</option>
    <option value="Class 10">Class 10</option>
    <option value="Class 11">Class 11</option>
    <option value="Class 12">Class 12</option>
    <option value="Under Graduate">Under Graduate</option>
    <option value="Graduated">Graduated</option>
    <option value="Others">Others</option>
</select>
<!-- <input type="text" name="edu" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Pincode !"> -->
</div>
<div class="col-4">
    <label class=" text-white mt-4">&nbsp; SESSION</label><br>
    <select name="year" id="year" class="form-control w-75 mt-2 " required>
        <option value="" selected disabled>SESSION</option>
        <option value="2010">2010-2011</option>
        <option value="2011">2011-2012</option>
        <option value="2012">2012-2013</option>
        <option value="2013">2013-2014</option>
        <option value="2014">2014-2015</option>
        <option value="2015">2015-2016</option>
        <option value="2016">2016-2017</option>
        <option value="2017">2017-2018</option>
        <option value="2018">2018-2019</option>
        <option value="2019">2019-2020</option>
        <option value="2020">2020-2021</option>
        <option value="2021">2021-2022</option>
        <option value="2022">2022-2023</option>
        <option value="2023">2023-2024</option>
        <option value="2024">2024-2025</option>
       
        
    </select>
</div>
<div class="col-4">
    <p id="pa"></p>
    <label class=" text-white mt-4">&nbsp; Date Of Admission</label>
    <input type="date" name="date" id="admission" class="form-control w-75 mt-2 bg-transparent text-white" required placeholder="Enter Your Pincode !" >
    <script>
         $('#year').bind('change', function() { 
           var y =  $('#year').val();
            $('#admission').attr("max", y+"-12-31");
         })
                </script>
</div>
<!-- <div class="col-4">
<label class=" text-white mt-4">&nbsp; Session</label>
<input type="text" name="session" disabled     id="session" class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Pincode !">
<script type="text/javascript">
    $(document).ready(function() {
        function onchange() {
            //Since you have JQuery, why aren't you using it?
            // var bo = $('#admission');
            // var box = bo.getYear();
            var box1 = $('#admission');
            var box2 = $('#session');
            box2.val(box1.val());
        }
        $('#admission').on('change', onchange);
    });
</script>
</div> -->
<div class="col-4">
    <label class=" text-white mt-4">&nbsp; Course</label>
                <select name="course" id="" class="form-control w-75">
                    <option value="0" selected disabled>Select</option>
                    <?php 
                    include 'config.php';
                    $sqlSubSkill = "SELECT subSkillName,skillUnder,id,duration FROM subSkill WHERE skillUnder = {$_SESSION['skill']}";
                    $resultSubSkill = mysqli_query($conn, $sqlSubSkill) or die('Query Fail For Category');
                    while ($rowSubSkill = mysqli_fetch_assoc($resultSubSkill)) {
                    ?>
                        <option value="<?php echo $rowSubSkill['id'] ?>"><?php echo $rowSubSkill['subSkillName'] ?> &nbsp;-&nbsp; <?php echo $rowSubSkill['duration'] ?> Months</option>
                    <?php }; ?>
                   
                </select>
</div>
<div class="col-12">
<input type="submit" name="submit" value="Submit !" id="submit" class="form-control  w-50 m-auto mt-2 bg-transparent text-white" >

</div>

</form>






      
    </div>
</div>


<?php include 'instituteFooter.php';




?>


