<?php
include 'config.php';
// $match = false;
// $matchP = false;
// $c = "SELECT phone,aadhar FROM institute";
// $rc = mysqli_query($conn,$c) or die("check fail"); 
// while($roc = mysqli_fetch_assoc($rc)){
//     if($roc['aadhar'] == $aadhar){
    //         $match = true;
    //     };
    //     if($roc['phone'] == $phone){
        //         $matchP = true;
        //     }
        
        // };
        
        if ( isset($_POST['submit'])) {
            $aadhar = mysqli_real_escape_string($conn, $_POST['aadhar']);
            $phone = mysqli_real_escape_string($conn, $_POST['phone']);
            
            $error = array();
            
            session_start();
            
            $folder = mkdir("institute-images/" . $aadhar, 0755);
            mkdir("institute-images/" . $aadhar . "/pp", 0755);
            mkdir("institute-images/" . $aadhar . "/aadhar", 0755);
            mkdir("institute-images/" . $aadhar . "/students", 0755);
            // echo "<br>".$folder;
            // move_uploaded_file($file_temp1,$folderf);
            
            $folderf = "institute-images/" . $aadhar . "/pp" . "/";
            $folderfs = "institute-images/" . $aadhar . "/";
            
            
            
            if (isset($_FILES['img1'])) { 
                $file_temp1 = $_FILES['img1']['tmp_name'];
                $file_type1 = $_FILES['img1']['type'];
                $file_name1 = $_FILES['img1']['name'];
                $file_size1 = $_FILES['img1']['size'];
                if ($file_size1 > 307200) {
            $error[] = "Front Picture Of Center File Must Be Less Then 300KB !";
        }
        if (empty($error) == true) {
            
            move_uploaded_file($file_temp1, $folderfs . $file_name1);
        } else {
            print_r($error);
            die();
        }
        
    }
    if (isset($_FILES['img2'])) { 
        $file_temp2 = $_FILES['img2']['tmp_name'];
        $file_type2 = $_FILES['img2']['type'];
        $file_name2 = $_FILES['img2']['name'];
        $file_size2 = $_FILES['img2']['size'];
        if ($file_size2 > 307200) {
            $error[] = "Inside Picture Of Center File Must Be Less Then 300KB !";
        }
        if (empty($error) == true) {
            
            move_uploaded_file($file_temp2, $folderfs . $file_name2);
        } else {
            print_r($error);
            die();
        }
        
    }

    if (isset($_FILES['img3'])) { 
        
        $file_temp3 = $_FILES['img3']['tmp_name'];
        $file_type3 = $_FILES['img3']['type'];
        $file_name3 = $_FILES['img3']['name'];
        $file_size3 = $_FILES['img3']['size'];
        if ($file_size3 > 307200) {
            $error[] = "Inside Picture No-2 Of Center File Must Be Less Then 300KB !";
        }
        if (empty($error) == true) {
            
            move_uploaded_file($file_temp3, $folderfs . $file_name3);
        } else {
            print_r($error);
            die();
        }
        
    }
    if (isset($_FILES['pimg'])) { 
        
        $fileP_temp3 = $_FILES['pimg']['tmp_name'];
        $fileP_type3 = $_FILES['pimg']['type'];
        $fileP_name3 = $_FILES['pimg']['name'];
    $fileP_size3 = $_FILES['pimg']['size'];
    if ($fileP_size3 > 307200) {
        $error[] = "Passport Size File Must Be Less Then 300KB !";
    }
    if (empty($error) == true) {
        
        move_uploaded_file($fileP_temp3, $folderf . $fileP_name3);
    } else {
        print_r($error);
        die();
    }
    
}

if (isset($_FILES['aadharFront'])) { 
    $aadharFront = $_FILES['aadharFront']['name'];
    $aadharBack = $_FILES['aadharBack']['name'];
    $aadharFrontSize = $_FILES['aadharFront']['size'];
    if ($aadharFrontSize > 307200) {
        $error[] = "Aadhar/pan Front File Must Be Less Then 300KB !";
    }
    
    $aadharBackSize = $_FILES['aadharBack']['size'];
    if ($aadharBackSize > 307200) {
        $error[] = "Aadhar Back File Must Be Less Then 300KB !";
    }
    $aadharFrontTmp = $_FILES['aadharFront']['tmp_name'];
    $aadharBackTmp = $_FILES['aadharBack']['tmp_name'];
    
    if (empty($error) == true) {
        
        move_uploaded_file($aadharFrontTmp, $folderfs ."aadhar/". $aadharFront);
        move_uploaded_file($aadharBackTmp, $folderfs ."aadhar/". $aadharBack);
    } else {
        print_r($error);
        die();
    }
    
}
// echo $pp;

// echo "<br>".$folderf;
// rename("institute-images/".$file_name1,"institute-images/pp/"."PP".".".$pp);
// die();
// die();
$name = mysqli_real_escape_string($conn, $_POST['name']);
$fname = mysqli_real_escape_string($conn, $_POST['fname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $institutenamme = mysqli_real_escape_string($conn, $_POST['institutenamme']);
    $skill = mysqli_real_escape_string($conn, $_POST['skill']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);
    $powerBackup = $_POST['powerBackup'];
    $airCondining = $_POST['airCondining'];
    $noOfTeacher = mysqli_real_escape_string($conn,$_POST['noOfTeacher']);
    $noOfStudent = mysqli_real_escape_string($conn,$_POST['noOfStudent']);
    $noOfClassRoom = mysqli_real_escape_string($conn,$_POST['noOfClassRoom']);
    $centerArea = mysqli_real_escape_string($conn,$_POST['centerArea']);
    $district = mysqli_real_escape_string($conn,$_POST['district']);
    $education = $_POST['education'];
    $dob = $_POST['dob'];
        // $pp = $_POST['pp'];

    $pass = bin2hex($_POST['pass']);


    // $course = $_POST['course'];  
    $date = date('d-m-y');
    date_default_timezone_set('Asia/Kolkata');
    $time = date("h:i:s");

    echo $date;


$to = "multilink.infotech@gmail.com";
$s = "New Center Application !";
$m = $name.$institutenamme.$skill.$state.$phone.$aadhar;
$f = $email;
$h = "From : $f";
// mail($to,$s,$m,$h);

echo "send!";


    $sql = "INSERT INTO `institute`( `name`, `fname`,`aadhar`, `phone`, `email`, `gender`, `state`, `institutename`,`skill`, `address`, `pincode`,`date`,`time`,`pass`,`approve`,`img1`,`img2`,`img3`, `pp`, `aadharFront`, `aadharBack`, `dob`, `education`, `district`, `centerArea`, `noOfClassRoom`, `noOfStudent`, `noOfTeacher`, `airCondining`, `powerBackup`)
     VALUES ('$name','$fname','$aadhar','$phone','$email','$gender','$state','$institutenamme','$skill','$address','$pincode','$date','$time','$pass','cfcd208495d565ef66e7dff9f98764da','$file_name1','$file_name2','$file_name3','$fileP_name3','$aadharFront','$aadharBack','$dob','$education','$district','$centerArea','$noOfClassRoom','$noOfStudent','$noOfTeacher',$airCondining,$powerBackup);";
    $sql .= "UPDATE `skills` SET `noOfStudentEnrollment`= noOfStudentEnrollment +1 WHERE `id` = $skill;";
    $sql .= "UPDATE `state` SET `noOfInstituteRegistered`=  noOfInstituteRegistered +1 WHERE stateId = $state";
    echo $sql;
    $updateResult = mysqli_multi_query($conn, $sql) or die("update fail");
    header('Location: ' . $path . 'form.php');
} else {
    echo "<h1 style='text-align:center'>AADHAR / PHONE NUMBER ALRESDY EXITS ! IF YOU DIDN'T REGISTERED PLEASE CONTACT US</h1>";
}
