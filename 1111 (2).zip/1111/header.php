
<?php include_once "config.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
   
    <title>Document</title>

  

     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="bootstrap.css">
     <link rel="stylesheet" href="scss.scss">
     <link rel="stylesheet" href="ani.scss">
     <link rel="stylesheet" href="jquery.js">
     <link rel="stylesheet" href="ui/css/uikit.css">
     <link rel="stylesheet" href="ui/js/uikit.js">
     <link rel="stylesheet" href="jquery.js">
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<!-- icon -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<!-- UIkit CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/css/uikit.min.css" />

<!-- UIkit JS -->
<script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit-icons.min.js"></script>

<!-- jquery -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

<!-- fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@200&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Gabarito:wght@500&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">

<style>
    body{
        font-family: "Red Hat Display", sans-serif;
    }
    .name{
        font-family: "Red Hat Display", sans-serif;
    }
    .big{
        font-weight: lighter;
        font-size: 50px;
        font-family: "Red Hat Display", sans-serif;
        border-left: 5px;
    border: 5px solid;
    border-top-color: transparent;
    border-right-color: transparent;
    border-bottom-color: transparent;
    }
    .font{
        font-family: "Red Hat Display", sans-serif;

    }
    .brown{
        background-color: #d17b30;
    }
    .blue{
        background-color: #01789e;
    }
    .purple{
        background-color: #c3a9ff;
    }
    .bb-t{
        color:wheat;
    }
    .brown-t{
        color: #d17b30;
    }
    .blue-t{
        color: #01789e;
    }
    .purple-t{
        color: #c3a9ff;
    }

    .lg{
    background-color: #017e7e;
}
.lg-t{
    color: #017e7e;
}

.g{
    background-color: #045d5d;
}
.g-t{
    color: #045d5d;
}
.g-tt{
    color: #99d9d9;
}

ul li a{
    /* color: #99d9d9; */
    color: white;
    font-weight: 500;
    text-decoration: none;
    /* text-shadow: 3px 3px 8px #045d5d; */
    font-family: "Red Hat Display", sans-serif;
}
ul li a:hover{
    /* color: white; */
    color: #99d9d9;
    text-decoration: none;
}
#password_rules ul li {
        /*font-size: 12px;
        font-weight: normal;*/
        color: tomato;
    }
    #password_rules ul li.complete {
        color: #045d5d;
    }
    span.togglePassword {
        color: gray;
        font-size: 12px;
        cursor: pointer;
    }

</style>

</head>
<body>

    <div class=" text-center">
     <p class="mb-0 font  lg text-white">

         <?php echo $cname ?>
     </p>
    </div>
<div class=" container-fluid  sticky-top bg-white">
           

        <div class="row d-flex justify-content-between align-items-center p-2  g">
            <div class="col-md-3 ">
                <img src="images/logo.png" width="60px" alt="" srcset="" class="p-0 m-0">
            </div>
            <div class="col-md-9">
                <ul class="d-flex justify-content-center m-0" style="list-style-type:none">
                    <li class="ms-4 "><a href="index.php">HOME</a></li>
                    <li class="ms-4 "><a href="about.php">ABOUT</a></li>
                    <li class="ms-4 "><a href="course.php">COURSE</a></li>
                    <li class="ms-4 "><a href="document.php">DOCUMENT VERIFICATION</a></li>
                    <li class="ms-4 "><a href="newInstitute.php">GET YOUR FRANCHISE</a></li>
                    <li class="ms-4 "><a href="form.php">INSTITUTE LOGIN</a></li>
                </ul>
            </div>
        </div>
       
       
    </div>
    <!-- <br> -->
