<?php
include "headerInstitute.php";
include "config.php";

$reg = $_GET['reg'];
$ff = "admitCard/".$reg.".txt";
$myfile = fopen("admitCard/".$reg.".pdf", "r") or die("Unable to open file!");
// echo fgets($myfile);
// fclose($myfile);

// Output one line until end-of-file
while(!feof($myfile)) {
    echo "<br>". fgets($myfile) . "<br>";
  }

  echo "<a href='{$ff}' download >Download</a>";
  fclose($myfile);

?>