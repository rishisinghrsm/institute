<?php 
include 'config.php';

// if(isset($_POST['submit'])){
    // if()
session_start();





$nameid = $_POST['id'];
echo $nameid;
// die();
// $fname = mysqli_real_escape_string($conn,$_POST['fname']);
// $duration = mysqli_real_escape_string($conn,$_POST['duration']);
$institutenamme = $_SESSION['id'];
$skill = $_SESSION['skill'];
// $subSkill = $_POST['subSkill'];
$percentage = mysqli_real_escape_string($conn,$_POST['percentage']);
$grade = "C";
// $course = $_POST['course'];  
// $date =$_SESSION['date'];
$todayDate = date('d-m-y');
date_default_timezone_set('Asia/Kolkata');
$time = date("h:i:s");

if($percentage > 0 AND $percentage < 39 ){
    $grade = "C";
}else if($percentage >= 40  AND $percentage < 59 ){
    $grade = "B";
}else if($percentage >= 60 AND $percentage < 74 ){
    $grade = "A";
}else if($percentage >= 75  ){
    $grade = "A+";
}



$certificateNo = uniqid();

// $sqlStuInfo = "SELECT * FROM newStudent WHERE id = {$name};";
$sqlPay = "UPDATE `newStudent` SET `payment`=  1 WHERE newStudent.id = $nameid";
echo $sqlPay;
// die();
$resultStuPay = mysqli_query($conn,$sqlPay) or die("update fail");





$sqlStuInfo = "SELECT * FROM newStudent
                left join subskill on subskill.id = newStudent.course
 WHERE newStudent.id = {$nameid}";
// $sqlStuInfo .= "UPDATE `newStudent` SET `payment`=  1 WHERE id = {$name}";
echo $sqlStuInfo;
// die();
$regNo = '';
$resultStuInfo = mysqli_query($conn,$sqlStuInfo) or die("update fail");
while($rowStuInfo = mysqli_fetch_assoc($resultStuInfo)){
    $fname = $rowStuInfo['fname'];
    $name = $rowStuInfo['name'];
    $date = $rowStuInfo['date'];
    $state = $rowStuInfo['state'];
    $regNo = $rowStuInfo['regNo'];
    $subSkill = $rowStuInfo['course'];
    $duration = $rowStuInfo['duration'];
    // global $nameid;
    $stuId = $rowStuInfo['id'];
};



$binName = hex2bin($nameid);
// ---------------------------------------------------------------------------------------------------

// $text = $name.$certificateNo.$regNo; 
// // $pixel_Size=30;
// $pixel_Size = 10; 
// $frame_Size = 10; 
// $qrpath = 'qr/generatedQr/ ';

// $file = $qrpath.uniqid().".png"; 
// // QR Code generation using png() 
// // When this function has only the 
// // text parameter it directly 
// // outputs QR in the browser 
// QRcode::png($text,$file, $pixel_Size, $frame_Size); 
// echo "<center><img src='".$file."'></center>";



// ---------------------------------------------------------------------------------------------------



$time=strtotime($date);
$month=date("m",$time);
$year=date("y",$time);
// $regNo ="";
$sql = "INSERT INTO `certificate`(`studentId`, `certificateHolder`, `certificateHoldderFather`, `skill`, `startingDate`, `duration`, `subskill`, `institute`, `grade`, `percentage`, `certificateIssueDate`, `certificateNo`) 
VALUES ('$nameid','$name','$fname','$skill','$date','$duration','$subSkill','$institutenamme','$grade','$percentage','$todayDate','$certificateNo');";
$sql .= "UPDATE `state` SET `noOfInstituteRegistered`=  noOfInstituteRegistered +1 WHERE stateId = {$state};";
$sql .= "UPDATE `newStudent` SET `payment`=  1 WHERE id = $nameid ";

                    $updateResult = mysqli_multi_query($conn,$sql) or die("update fail");
                    header('Location: '.$path.'f.php?num='.$nameid);


                // }else{
                //     echo "error";
                // }

?>