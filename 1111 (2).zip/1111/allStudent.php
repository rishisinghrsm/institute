<?php include 'headerInstitute.php';
$paym = $_SESSION['payment'];
if(!$paym = "1"){
    header('Location: '.$path.'checkout.php');
};
;?>


<table class="uk-table uk-table-striped uk-table-hover" >
    <thead class="sticky-top uk-background-muted fw-bold">
        <tr >
            <th class="fw-bold">S. No.</th>
            <th class="fw-bold " >Image</th>
            <th class="fw-bold " >Name</th>
            <th class="fw-bold " >Phone No.</th>
            <th class="fw-bold " >Registration No.</th>
            <th class="fw-bold " >Course</th>
            <th class="fw-bold " >Admit Card</th>
            <th class="fw-bold " >Certificate</th>
            <th class="fw-bold " >Edit</th>
            <th class="fw-bold " >Delete</th>
        </tr>
    </thead>
    <tbody>
    <?php
                    include 'config.php';
                    $limit = 10;
                    if(isset($_GET['page'])){

                        $page = $_GET['page'];
                    }else{
                        $page = 1;

                    }
                    $offest = ($page -1)* $limit;
                    $num = 1;
                    global $idfora;
                     $idfora = '';
                    $sqlForStu = "SELECT *,newStudent.id FROM `newStudent`
                    LEFT JOIN `subSkill` ON subSkill.id = newStudent.course
                     WHERE newStudent.institute = {$_SESSION['id']} ORDER BY newStudent.id DESC LIMIT {$offest},{$limit};";
                    
                    // echo $sqlForStu;
                    $resultForStu = mysqli_query($conn, $sqlForStu) or die('Query Fail For Category');
                    while ($rowForStu = mysqli_fetch_assoc($resultForStu)) {
                        $idfora = bin2hex($rowForStu["id"]);
                    ?>
        <tr class="uk-box-shadow-small uk-box-shadow-hover-large uk-padding ">
        <td class="fs-2 text-black-50 " style="text-shadow: 4px 4px 4px gray;"><?php echo  $num; ?></td>
        <!-- <td><?php echo $rowForStu['id'] ?></td> -->
        <td><img src="institute-images/<?php echo $_SESSION['aadhar'].'/'.'students/'.$rowForStu['aadhar']."/".$rowForStu['img'] ?>" alt="" class="rounded-circle" style="max-width: 40px;min-width:40px;min-height: 40px;max-height:40px;"></td>
        <td class="fw-bold"><?php echo substr($rowForStu['name'], 0, 20)."" ?></td>
        <td><?php echo $rowForStu['phone'] ?></td>
       
        <td><?php 
        if($rowForStu['admitCard'] == 0){
            // echo "efe";
            echo "<a href='newStudentSubmitRedirectSubmit.php?id={$rowForStu['id']}'>Generate</a>";
        }else{

            echo $rowForStu['regNo'] ; 
        }
            ?></td>
        <td><?php echo substr($rowForStu['subSkillName'],0,15)."" ?></td>
        <td class='text-center m-auto'>
        <?php 
         if($rowForStu['admitCard'] == 0){
            // echo "efe";
            echo "<p href='#' disabled >Generate Registration No. First</p></td>";
        }else{

            echo " <a href='admitCard.php?id=$idfora'  style='text-shadow: 4px 4px 4px #88fdff;'> <i class='bi bi-arrow-down-circle fs-5 text-center'></i></a></td>" ; 
        }
        ?>    
       
        <?php
       
       if($rowForStu['admitCard'] == 1 && $rowForStu['payment'] == 1){
           
              echo "<td><a href='showCertificate.php?id=$idfora'  class='' style='color:#045d5d'>ISSUED ! <i class='bi bi-check2-all'></i></a></td>";
            //   echo $rowForStu['id'];
           
               
    
    }else if($rowForStu['admitCard'] == 1 && $rowForStu['payment'] == 0){
        

            echo "<td><a href='getCertificateSecondWay.php?id=$idfora' class='text-danger' style=''>NOT ISSUED ! <i class='bi bi-x-lg'></i></a></td>";
       
            
        
    }else if($rowForStu['admitCard'] == 0 && $rowForStu['payment'] == 0){
        

        echo "<td><p  class='text-danger'>Generate Admit Card First ! !</p></td>";
   
      
}else{
    echo 'Error !';
}
     
     ?>
      <?php 
         if($rowForStu['payment'] == 0){
            // echo "efe";
            // echo "<p href='#' disabled >Generate Registration No. First</p></td>";
            ?>
            <td><a style="color:#045d5d" href="editStudent.php?id=<?php echo $rowForStu['id'] ?>" onclick="confirm('Want To Edit ?')" s><i class="bi bi-pencil-square fs-5"></i></a></td>
            <?php 
        }else{
            ?>
            <td><p   style="color: #d6d6d6;cursor: no-drop"><i class="bi bi-pencil-square fs-5"></i></p></td>

<?php 
            // echo " <a href='admitCard.php?id=$idfora'  style='text-shadow: 4px 4px 4px #88fdff;'> <i class='bi bi-arrow-down-circle fs-5 text-center'></i></a></td>" ; 
        }
        ?>    
      <?php 
         if($rowForStu['payment'] == 0){
            // echo "efe";
            // echo "<p href='#' disabled >Generate Registration No. First</p></td>";
            ?>
            <td><a href="deleteStudent.php?id=<?php echo $rowForStu['id'] ?>" style="color:#045d5d;"  onclick="confirm('Want To Delete ?')" ><i class="bi bi-trash fs-5"></i></a></td>
            <?php 
        }else{
            ?>
            <td><p   style="color: #d6d6d6;cursor: no-drop"><i class="bi bi-trash h fs-5"></i></p></td>

<?php 
            // echo " <a href='admitCard.php?id=$idfora'  style='text-shadow: 4px 4px 4px #88fdff;'> <i class='bi bi-arrow-down-circle fs-5 text-center'></i></a></td>" ; 
        }
        ?>    
            
        </tr>
        
        <?php $num++; 
        
        $sqlForStuUpdate = "UPDATE newStudent SET regNo = regNo + $idfora WHERE id = $idfora";
        $resultForStuUpdate = mysqli_query($conn, $sqlForStuUpdate) or die('Query Fail For Category');
    };

        // mysqli_fetch_assoc($resultForStuUpdate);

        
        ?>
        
        <?php 
        if(isset($_GET['v']) == "generated"){
            echo " <script>
UIkit.notification('Generated Successfully');
        </script>";
        }

        ?>
        <?php 
        if(isset($_GET['submit']) == "true"){
            echo " <script>
UIkit.notification('Updated Successfully');


        </script>
        <script>
   history.pushState(null, null, document.URL);
window.addEventListener('popstate', function () {
    history.pushState(null, null, document.URL);
});
</script>
        
      ";
        }

        ?>
    </tbody>
</table>
<div class="text-center d-flex justify-content-center">

    <?php 
$sqlp = "SELECT * FROM newStudent WHERE institute = {$_SESSION['id']}";
$resultp = mysqli_query($conn,$sqlp) or die("Pagination Fail");
if(mysqli_num_rows($resultp) > 0){
    $total_records = mysqli_num_rows($resultp);
    $total_pages = ceil($total_records/$limit);
    echo '<ul class="pagination m-auto">';
for($i = 1; $i<= $total_pages ;$i++){
    if($i == $page){
        $activeCalss = "active";
    }else{
        $activeCalss = "";

    }
    echo '<li class="page-item '.$activeCalss.'"><a class="page-link" href="allStudent.php?page='.$i.'">'.$i.'</a></li>';
}
echo '</ul>';
}

?>
</div>

<script>
    
</script>

    
