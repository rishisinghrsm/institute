<?php 

include 'config.php';
session_start();
$sql = "SELECT regNo ,id FROM newStudent WHERE name = '{$_SESSION['stuName']}' AND fname =' {$_SESSION['fname']}' AND course = '{$_SESSION['course']}' ORDER BY id DESC";
// echo $sql;
$result = mysqli_query($conn,$sql) or die('Redirect Fail');
while($row = mysqli_fetch_assoc($result)){

    // echo '<a href="newStudentSubmitRedirectSubmit.php?id=.{$row["id"]}">CONTINUE</a>";
    // header('Location: '.$path.'newStudentSubmitRedirectSubmit.php?id='.print_r($row['id']));


    print_r($row['id']);
    die();

?>

<a href="newStudentSubmitRedirectSubmit.php?id=<?php echo $row['id']?>">Continue</a>
<?php }?>