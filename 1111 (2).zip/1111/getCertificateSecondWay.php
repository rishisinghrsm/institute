<?php include "headerInstitute.php"; ?>






<div class="container-fluid " style="min-height: 90vh;background-color:whitesmoke">
    <div class="row  d-flex justify-content-center align-items-center " style="min-height: 90vh;">
        
        <div class="col-md-7  d-flex align-items-center justify-content-center    " >
            <div class="row shadow-lg rounded p-2 bg-white">
                <div class="col-4 p-5 ps-2 fs-3 g text-white rounded">
                    <p class="mt-4">DOCUMENT </p>
                    <p >VERIFICATION !</p>
                </div>
                <div class="col-8 p-5 fw-bold">
                <form action="certificatePay.php" method="post">
                <label class=" g-t mt-4">&nbsp; Student Name<span class="fs-4 text-white">*</span></label>
                <!-- <select name="name" id="" class="form-control w-100" required> -->
                    <!-- <option value="0" selected disabled>Select</option> -->
                    <?php
                    include 'config.php';
                    $id = hex2bin($_GET['id']);
                    $sqlForStu = "SELECT * FROM `newstudent` WHERE id = $id";

                    $resultForStu = mysqli_query($conn, $sqlForStu) or die('Query Fail For Category');
                    while ($rowForStu = mysqli_fetch_assoc($resultForStu)) {
                    ?>
                    <input type="hidden" name="id" value="<?php echo bin2hex($id);?>" id="">
                        <input class="form-control w-100" value="<?php echo $rowForStu['name']; ?>" disabled >

                        
                        <label class=" g-t mt-4">&nbsp; Duration<span class="fs-4 text-white">*</span></label>
                        <?php
                // include 'config.php';
                $sqlSubSkill = "SELECT subSkillName,id,skillUnder,duration FROM subSkill WHERE id = {$rowForStu['course']}";
                // echo $sqlSubSkill;
                $resultSubSkill = mysqli_query($conn, $sqlSubSkill) or die('Query Fail For Category');
                while ($rowSubSkill = mysqli_fetch_assoc($resultSubSkill)) {
                ?>
                <input type="text" name="duration" id=""  class="form-control w-100" disabled value="<?php echo $rowSubSkill['duration'] ?> Months">
                
                
            
            <label class=" g-t mt-4">&nbsp; Select Cource/Skill<span class="fs-4 text-white">*</span></label>
            <select name="subSkill" id="" class="form-control w-100"  disabled>
                <!-- <option value="0" selected disabled><?php echo $rowForStu['course']; ?></option> -->
               
                    <option value="<?php echo $rowSubSkill['id'] ?>"><?php echo $rowSubSkill['subSkillName'] ?></option>
                <?php }; ?>

            </select>


            <label class=" g-t mt-4">&nbsp; Percentage<span class="fs-4 text-white">*</span></label>
            <input type="number" name="percentage" required id=" " class="form-control w-100 mt-2 bg-transparent g-t" placeholder="Enter Your Institute's Name !">
           

            <?php }?>
            <input type="submit" name="submit" value="Submit !" id=" " class="form-control  w-100 mt-2  g-t">
            </form>
            

        </div>
    </div>
        </div>
    </div>
</div>
<?php include 'footer.php' ?>