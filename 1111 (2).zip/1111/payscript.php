
<?php
// include "headerinstitute.php";
include 'config.php';
session_start();
$ss = "SELECT institutePayment FROM institute WHERE id = {$_SESSION['id']}";
$rr = mysqli_query($conn,$ss);
$rr = mysqli_fetch_assoc($rr);

if(!$rr['institutePayment'] == 0){
    header('Location: '.$path.'instituteDashboard.php');
}

$name =  $_SESSION['name'] ;
// echo $name;
$email =  $_SESSION['email'] ;
// echo $email;
$phone =  $_SESSION['phone'] ;
// echo $phone;
$id =  $_SESSION['id'] ;
// echo $id;
// $name =  $_SESSION['name'] ;
$apikey = "rzp_test_kTwHLDOweWLIj0";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <title>
        <?php
        echo $_SESSION['instituteName']
        ?>
    </title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit-icons.min.js"></script>

    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Gabarito:wght@500&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">


    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        body{
            min-height: 100vh;
        }
        .name {
            font-family: "Red Hat Display", sans-serif;
        }

        .big {
            font-weight: lighter;
            font-size: 50px;
            font-family: "Red Hat Display", sans-serif;
            border-left: 5px;
            border: 5px solid;
            border-top-color: transparent;
            border-right-color: transparent;
            border-bottom-color: transparent;
        }

        .font {
            font-family: "Red Hat Display", sans-serif;

        }

        .brown {
            background-color: #d17b30;
        }

        .blue {
            background-color: #01789e;
        }

        .purple {
            background-color: #c3a9ff;
        }

        .bb-t {
            color: wheat;
        }

        .brown-t {
            color: #d17b30;
        }

        .blue-t {
            color: #01789e;
        }

        .purple-t {
            color: #c3a9ff;
        }

        ul {

            text-decoration: none;
        }

        .navv li {
            text-decoration: none;
            /* text-decoration-color: transparent; */
            list-style-type:none;
            margin-top: 10px;
            border-bottom: 1px solid white;
        }

        .navv li a {
            color: white;
        }
        .activee{
            /* background-color: #d17b30; */
            /* color: red; */
            font-weight: 400;
        }
        #dis{
            background-color: transparent;
            border: 0px;
        }
        #dis:focus {
  border: 3px solid tomato;
  transform: scale(1.2);
}

.lg{
    background-color: #017e7e;
}
.lg-t{
    color: #017e7e;
}

.g{
    background-color: #045d5d;
}
.g-t{
    color: #045d5d;
}
.g-tt{
    color: #99d9d9;
}
.razorpay-payment-button{
    position: absolute;
    top: 50%;
    left: 48%;
    background-color: #045d5d;
    padding: 5px 10px;
    border:  2px solid #01789e;
    color: white;
    border-radius: 33px;
    font-size: large;
}
    </style>
</head>

<body style="min-height: 100vh;">
<form action="thankyou.php" method="POST">
<!-- <form action="https://www.example.com/success/" method="POST"> -->
<script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="rzp_test_kTwHLDOweWLIj0" 
    data-amount="10000" 
    data-currency="INR"
    data-id="<?php echo 'ORD_'.$id; ?>"
    data-buttontext="Pay Now"
    data-name="Bharat Job Finer"
    data-description="A Wild Sheep Chase is the third novel by Japanese author Haruki Murakami"
    data-image="http://localhost/1111/images/logo.png"
    data-prefill.name="<?php echo $cname; ?>"
    data-prefill.email="<?php echo $email; ?>"
    data-prefill.contact="<?php echo $phone; ?>"
    data-theme.color="#F37254"
></script>
<input type="hidden" custom="Hidden Element" value="<?php echo $id; ?>" name="hidden"/>
<!-- </form> -->
</form>

