
<?php 
 header('Content-type: image/jpeg');
$font=realpath('arial.ttf');
$image=imagecreatefromjpeg("certificate.jpeg");
$color=imagecolorallocate($image, 51, 51, 102);
$date=date('d F, Y');
imagettftext($image, 18, 0, 880, 188, $color,$font, $date);
$name="YOUTUBE";
imagettftext($image, 48, 0, 120, 520, $color,$font, $name);
//imagejpeg($image,"certificate/$name.jpg");
imagejpeg($image);
imagedestroy($image);


header('Content-type: image/jpeg');
$font=realpath('arial.ttf');
$image=imagecreatefromjpeg("format.jpg");
$color=imagecolorallocate($image, 51, 51, 102);
$date=date('d F, Y');
imagettftext($image, 18, 0, 880, 188, $color,$font, $date);
$name="YOUTUBE";
imagettftext($image, 48, 0, 120, 520, $color,$font, $name);
//imagejpeg($image,"certificate/$name.jpg");
imagejpeg($image);
imagedestroy($image);

// include 'config.php';
// $id = hex2bin($_GET['num']);
// session_start();
// $sqlins = "UPDATE certificate SET certificateImg = 1  WHERE studentId = $id";
// mysqli_query($conn,$sqlins); 
// $sql = "SELECT * FROM newStudent WHERE id = $id AND institute = {$_SESSION['id']} AND payment = 1";
// $result = mysqli_query($conn,$sql) or die("death eeeeeeeeeee");
// while($row = mysqli_fetch_assoc($result)){
    //     if($row['payment'] != 1){
        //         header('Location: showCertificate.php?fee=due');
        //     }
        // $name=$row['name'];
        
        // $name="RISHI SINGH";
?>