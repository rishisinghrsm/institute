<?php

use function PHPSTORM_META\type;    

include 'config.php';
// session_start();
// $id = $_POST['id'];
$id = $_GET['id'];
// var_dump($id);
$id = (string) $id;
// var_dump($id);
//  type($id);
// die();
$sql = "UPDATE `newStudent` SET `regNo` = CONCAT(regNo, $id), `admitCard` = 1 WHERE id = $id";
echo $sql;
// die();
$result = mysqli_query($conn,$sql) or die('Redirect Fail');
// mysqli_fetch_assoc($result);
header('Location:allStudent.php?v=generated');

?>