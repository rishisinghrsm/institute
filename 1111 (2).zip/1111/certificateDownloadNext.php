<?php include 'headerInstitute.php' ?>


<?php
                    include 'config.php';
                    // $num = 1;
                    $id = hex2bin($_GET['id']);
                    $admitCardPath ="";
                    // session_start();
                    $sqlForStu = "SELECT * FROM `certificate` 
                    LEFT JOIN subSkill ON subSkill.id = certificate.subskill
                    WHERE certificate.id = {$id} ";
                    // echo $sqlForStu;
                    $resultForStu = mysqli_query($conn, $sqlForStu) or die('Query Fail For Category');
                    while ($rowForStu = mysqli_fetch_assoc($resultForStu)) {
                        ?>
<div class="text-center fs-2 ">

    <a href="admitCard/<?php echo $rowForStu['regNo']?>.txt" class="text-center"  download>DOWNLOAD</a>
</div>
      
        <?php  };?>
 
        
