<?php include "headerInstitute.php";


?>
<?php include 'qr/phpqrcode/qrlib.php';  

// date_default_timezone_set('Asia/Kolkata');
// $date = date("l jS \of F Y h:i:s A");
// // $date = date("dmy ");
// echo $date;
// // $t = time();
// $t = date_default_timezone_get();
// $text = "Dhananjay ISngh"; 
// // $pixel_Size=30;
// $pixel_Size = 10; 
// $frame_Size = 10; 
// $path = 'qr/generatedQr/ ';

// $file = $path.uniqid().".png"; 
// // QR Code generation using png() 
// // When this function has only the 
// // text parameter it directly 
// // outputs QR in the browser 
// QRcode::png($text,$file, $pixel_Size, $frame_Size); 
// echo "<center><img src='".$file."'></center>";

?>




<div class="container">

<?php
$id = $_GET['id'];
$sql = "SELECT * FROM institute
        left join state on state.stateId = institute.state
         WHERE institute.id = {$_SESSION['id']} ";
$result= mysqli_query($conn,$sql) or die("death");
$row = mysqli_fetch_assoc($result);

?>
    <form action="editInstituteSubmit.php" method="post" enctype="multipart/form-data">
        <div class="row lg p-5 mt-5">
        <p class="fs-3 text-white border-bottom " style="text-shadow: 4px 4px 10px black;">EDIT DETAILS !</p>
        <div class="col-4">
    <label class=" text-white mt-4">&nbsp;Institute Name</label>
    <input type="text" name="iname" id=" " value="<?php echo $row['institutename'] ?>" class="form-control w-100 mt-2 bg-transparent text-white" placeholder="Enter Your Name !" required>
    </div>
        <div class="col-4 text-center">
        <label class=" text-white mt-4 mb-2 ">&nbsp;Passport Size Photo</label><br>
        <div class="uk-inline border">
            <img src="institute-images/<?php echo $_SESSION['aadhar'].'/'.'pp/'. $row['pp'] ?>" style="max-width: 100px;max-height:120px;width: 100px;height: 120px;border:2px solid white; " alt="">
            <div class="uk-overlay-primary uk-position-cover"></div>
            <div class="uk-overlay uk-position-bottom uk-light">
                <!-- <p>Default Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> -->
            </div>
        </div>
        <!-- <img src="institute-images/<?php echo $_SESSION['aadhar'].'/'.'pp/'. $row['pp'] ?>" style="max-width: 100px;max-height:120px;width: 100px;height: 120px; " alt=""> -->
        <input type="file"  accept="image/jpeg,image/png,image/jpg,image/PNG,image/JPEG,image/JPG" name="img1" id=" " class="form-control w-75 text-center m-auto mt-2 bg-transparent text-white" placeholder="Enter Your Name !">
        <input type="hidden" name="hiddenImgName" value="<?php echo  $row['pp'] ?>">
        </div>
        <div class="col-4">
    <label class=" text-white mt-4">&nbsp; Name</label>
    <input type="text" name="name" id=" " value="<?php echo $row['name'] ?>" class="form-control w-100 mt-2 bg-transparent text-white" placeholder="Enter Your Name !" required>
    </div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Father's Name</label>
<input type="text" name="fname" id=" " value="<?php echo $row['fname'] ?>" class="form-control  mt-2 bg-transparent text-white" placeholder="Enter Your Father's Name !" required>
</div>
<!-- <div class="col-4">
<label class=" text-white mt-4">&nbsp; Mother's Name</label>
                <input type="text" name="mname" value="<?php echo $row['mname'] ?>" id=" " class="form-control  mt-2 bg-transparent text-white" placeholder="Enter Your Mother's Name !">
</div> -->
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Phone Number</label>
<input type="number" name="phone" id=" " value="<?php echo $row['phone'] ?>" class="form-control  mt-2 bg-transparent text-white" placeholder="Enter Your Phone Number !" required>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Aadhar Number</label>
<input type="number" name="aadhar" id=" " disabled value="<?php echo $row['aadhar'] ?>" class="form-control  mt-2 bg-transparent text-black-50 border-dark" placeholder="Enter Your Aaadhar Number !">
</div>
<div class="col-4">

<label class=" text-white mt-4">&nbsp; Email</label>
<input type="email" name="email" value="<?php echo $row['email'] ?>" id=" " class="form-control  mt-2 bg-transparent text-white" placeholder="Enter Your Email !" required>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Gender</label>
                <select name="gender" id="" class="form-control mt-2" required>
                    <option value="<?php echo $row['gender'] ?>" selected disabled>
                        <?php  if($row['gender'] == 'f' ){
                            echo "Female";
                        }else{
                            echo "Male";
                        }
                            ?>
                    </option>
                    <option value="m">Male</option>
                    <option value="f">Female</option>
                </select>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Education</label>
<input type="text" name="edu" id=" " disabled value="<?php echo $row['education'] ?>" class="form-control  mt-2 bg-transparent text-black-50 border-dark" placeholder="Enter Your Education Details !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Address</label>
<textarea name="address" id="" class="form-control  mt-2 bg-transparent text-white"><?php echo $row['address'] ?></textarea>
<!-- <input type="text" name="" id=" " value="" class="form-control  mt-2 bg-transparent text-white" placeholder="Enter Your Address !"> -->
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Pincode</label>
<input type="text" name="pincode" id=" " disabled value="<?php echo $row['pincode'] ?>" class="form-control  mt-2 bg-transparent text-black-50 border-dark" placeholder="Enter Your Pincode !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; State</label>
<input type="text" name="" id=" " disabled value="<?php echo $row['stateName'] ?>" class="form-control  mt-2 bg-transparent text-black-50 border-dark" placeholder="Enter Your Pincode !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; District</label>
<input type="text" name="" id=" " disabled value="<?php echo $row['district'] ?>" class="form-control  mt-2 bg-transparent text-black-50 border-dark" placeholder="Enter Your Pincode !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Center Area</label>
<input type="text" name="area" id=" "  value="<?php echo $row['centerArea'] ?>" class="form-control  mt-2 bg-transparent text-white" placeholder="Center Area!" required>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; No. Of Class Rooms</label>
<input type="text" name="class" id=" "  value="<?php echo $row['noOfClassRoom'] ?>" class="form-control  mt-2 bg-transparent text-white" placeholder="No Of Class Rooms !" required>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; No. Of Teachers</label>
<input type="text" name="teacher" id=" "  value="<?php echo $row['noOfTeacher'] ?>" class="form-control  mt-2 bg-transparent text-white" placeholder="No Of Teachers !" required>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; A/C available</label>
<select name="ac" id="" class="form-control  mt-2  " required>
    <option value="<?php echo $row['airCondining'] ?>" selected disabled>
        <?php
        if( $row['airCondining'] == 1){
            echo 'Yes';
        }
        else if( $row['airCondining'] == 0){
            echo 'No';
        }else{
            echo 'error';
        }
        ?>
    </option>
    <option value="1"  >Yes</option>
    <option value="0"  >No</option>
</select>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Power Backup</label>
<select name="pb" id="" class="form-control  mt-2 " required>
    <option value="<?php echo $row['powerBackup'] ?>" selected disabled>
        <?php
        if( $row['powerBackup'] == 1){
            echo 'Yes';
        }
        else if( $row['powerBackup'] == 0){
            echo 'No';
        }else{
            echo 'error';
        }
        ?>
    </option>
    <option value="1"  >Yes</option>
    <option value="0"  >No</option>
</select>
</div>
<!--  -->
<div class="col-12">
<input type="hidden" name="hidden" value="<?php echo $_GET['id'] ?>" id=" " class="form-control  w-50 m-auto mt-2 bg-transparent text-white" >
<input type="submit" name="submit" value="Submit !" id=" " class="form-control  w-50 m-auto mt-5 bg-transparent text-white" >

</div>

</form>






      
    </div>
</div>


<?php include 'instituteFooter.php' ?>