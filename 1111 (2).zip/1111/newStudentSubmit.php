<?php 
include 'config.php';

if(isset($_POST['submit'])){
    session_start();
// $img = $_FILES['file'];
$file_name1 = $_FILES['img1']['name'];
$file_size1 = $_FILES['img1']['size'];
$file_temp1 = $_FILES['img1']['tmp_name'];
$file_type1 = $_FILES['img1']['type'];
$name = $_POST['name'];
$_SESSION['stuName'] = $name;
$fname = $_POST['fname'];
$_SESSION['fname'] = $fname;
$mname = $_POST['mname'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$aadhar = $_POST['aadhar'];
$gender = $_POST['gender'];
$state = $_SESSION['state'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$course = $_POST['course'];
$_SESSION['course'] = $course;
$date = date('d-m-y');
date_default_timezone_set('Asia/Kolkata');
$time = date("l jS \of m y h:i:s");
$instituteId = $_SESSION['id'];

$time=strtotime($date);
$month=date("m",$time);
$year=$_POST['year'];
global $regNo;
$regNo = $state.$_SESSION['skill'].$month.$year.$instituteId;
echo $date;

if( file_exists("institute-images/".$_SESSION["aadhar"]."/students/".$aadhar)){

    mkdir("institute-images/".$_SESSION["aadhar"]."/students/".$aadhar, 0755);
    move_uploaded_file($file_temp1,"institute-images/". $_SESSION["aadhar"] ."/students/".$aadhar."/". $file_name1);
}else{
    mkdir("institute-images/".$_SESSION["aadhar"]."/students/".$aadhar, 0755);
    move_uploaded_file($file_temp1,"institute-images/". $_SESSION["aadhar"] ."/students/".$aadhar."/". $file_name1);
}
$sql = "INSERT INTO `newstudent`( `name`, `fname`, `mname`, `phone`, `email`,`aadhar`, `gender`, `state`, `address`, `pincode`, `course`,`date`,`yearOfAdmission`, `time`,`institute`,`regNo`,`img`) VALUES ('$name','$fname','$mname','$phone','$email',$aadhar,'$gender','$state','$address','$pincode','$course','$date','$year','$time','$instituteId','$regNo','$file_name1');";
$sql .= "UPDATE `skills` SET `noOfStudentEnrollment`= noOfStudentEnrollment+1 WHERE id = {$_SESSION['skill']};";
$sql .= "UPDATE `subskill` SET `noOfStudent`= noOfStudent+1 WHERE id = $course";
                    $updateResult = mysqli_multi_query($conn,$sql) or die("update fail");
                    header('Location:allStudent.php');


                }else{
                    echo "error";
                }



















?>