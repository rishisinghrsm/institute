<?php 
include 'qr/phpqrcode/qrlib.php';
include 'config.php';
// $id = hex2bin($_GET['num']);
$id = $_GET['num'];
session_start();
$sqlins = "UPDATE certificate SET certificateImg = 1 WHERE studentId = $id";
echo $sqlins;
mysqli_query($conn,$sqlins); 

// echo "cccccccccc";
// $sql = "SELECT *,certificate.duration FROM newStudent 
//  LEFT JOIN certificate on certificate.studentId = $id
//  LEFT JOIN subskill on subskill.id = certificate.skill
// WHERE newStudent.id = $id AND newStudent.institute = {$_SESSION['id']} AND payment = 1";
$sql = "SELECT *,certificate.duration FROM `certificate`
                    left join newStudent on newStudent.id = certificate.studentId 
                    LEFT JOIN subSkill ON subSkill.id = certificate.subskill
                    WHERE certificate.studentId = {$id} AND newStudent.institute = {$_SESSION['id']} AND payment = 1";
                    echo $sql;

$result = mysqli_query($conn,$sql) or die("death eeeeeeeeeee");
echo "cff";


if(mysqli_num_rows($result) > 0){
while($row = mysqli_fetch_assoc($result)){

if($row['payment'] != 1){
                header('Location: showCertificate.php?fee=due');
            };

            header('Content-type: image/jpeg');
            $font=realpath('arial.ttf');
            $image=imagecreatefromjpeg("certificate.jpeg");
            $color=imagecolorallocate($image, 51, 51, 102);
            $date=date('d F, Y');
            imagettftext($image, 18, 0, 1140, 1008, $color,$font, $date);
            $name=$row['name'];
            // $name="YOUTUBE";
            imagettftext($image, 25, 0, 620, 470, $color,$font, $name);
            imagettftext($image, 25, 0, 200, 300, $color,$font, $id);
            $fname=$row['fname'];
            imagettftext($image, 25, 0, 420, 545, $color,$font, $fname);
            $iname=$_SESSION['instituteName'];
            imagettftext($image, 25, 0, 420, 690, $color,$font, $iname);
            $regNo=$row['regNo'];
            imagettftext($image, 25, 0, 440, 930, $color,$font, $regNo);
            $certificateNo=$row['certificateNo'];
            imagettftext($image, 25, 0, 440, 1010, $color,$font, $certificateNo);
            $skill=$row['subSkillName'];
            imagettftext($image, 25, 0, 490, 620, $color,$font, $skill);
            $duration=$row['duration']." Months";
            imagettftext($image, 25, 0, 350, 770, $color,$font, $duration);
            $grade=$row['grade'];
            imagettftext($image, 25, 0, 750, 770, $color,$font, $grade);
            $percentage=$row['percentage'];
            imagettftext($image, 25, 0, 1280, 770, $color,$font, $percentage);
            
           
            // imagejpeg($image);
            imagejpeg($image,"institute-images/".$_SESSION['aadhar'].'/students/'.$row['aadhar']."/".$row['regNo']."_".$row['studentId'].".jpg");
            imagedestroy($image);

header('Location: showCertificate.php?submit=done');
        };
    }else{
        echo "ZERO DATA";
    }
    ?>