<?php 
include 'config.php';

if(isset($_POST['submit'])){
    
$id = $_POST['hidden'];
session_start();
if(empty($_FILES['img1']['name'])){

    $file_name1 = $_POST['hiddenImgName'];
}else{

    $file_name1 = $_FILES['img1']['name'];
    $file_size1 = $_FILES['img1']['size'];
    $file_temp1 = $_FILES['img1']['tmp_name'];
    $file_type1 = $_FILES['img1']['type'];
    move_uploaded_file($file_temp1,"institute-images/". $_SESSION["aadhar"] ."/pp/". $file_name1);
}

$name = $_POST['name'];
$iname = $_POST['iname'];
$fname = $_POST['fname'];
$phone = $_POST['phone'];
$email = $_POST['email'];
// $aadhar = $_POST['aadhar'];
$gender = $_POST['gender'];
$state = $_SESSION['state'];
$address = $_POST['address'];
// $pincode = $_POST['pincode'];
$area = $_POST['area'];
$class = $_POST['class'];
$teacher = $_POST['teacher'];
$ac = $_POST['ac'];
$pb = $_POST['pb'];


// $time=strtotime($date);
// $month=date("m",$time);
// $year=date("y",$time);
// global $regNo;
// $regNo = $state.$_SESSION['skill'].$month.$year.$instituteId;
// echo $date;
$sql = "UPDATE `institute` SET `name`='$name',`fname`='$fname',`phone`='$phone',`email`='$email',`gender`='$gender',`institutename`='$iname',`address`='$address',`pp` = '$file_name1',`centerArea`='$area',`noOfClassRoom`='$class',`noOfTeacher`='$teacher',`airCondining`= {$ac},`powerBackup`= {$pb} WHERE id = $id";
echo $sql;



                    $updateResult = mysqli_query($conn,$sql) or die("update fail");
                    header('Location:instituteDashboard.php?submit=trueIE');


                }else{
                    echo "error";
                }



















?>