<?php
// include "headerInstitute.php";
include 'config.php';
session_start();
$ss = "SELECT institutePayment FROM institute WHERE id = {$_SESSION['id']}";
$rr = mysqli_query($conn,$ss);
$rr = mysqli_fetch_assoc($rr);

if(!$rr['institutePayment'] == 0){
    header('Location: '.$path.'instituteDashboard.php');
}
if(!$_GET['a'] == "true"){
    header('Location: '.$path.'wait.php?a=');
}

?>
<?php 




?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <title>
        <?php
        echo $_SESSION['instituteName']
        ?>
    </title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit-icons.min.js"></script>

    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Gabarito:wght@500&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">


    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        body{
            min-height: 100vh;
        }
        .name {
            font-family: "Red Hat Display", sans-serif;
        }

        .big {
            font-weight: lighter;
            font-size: 50px;
            font-family: "Red Hat Display", sans-serif;
            border-left: 5px;
            border: 5px solid;
            border-top-color: transparent;
            border-right-color: transparent;
            border-bottom-color: transparent;
        }

        .font {
            font-family: "Red Hat Display", sans-serif;

        }

        .brown {
            background-color: #d17b30;
        }

        .blue {
            background-color: #01789e;
        }

        .purple {
            background-color: #c3a9ff;
        }

        .bb-t {
            color: wheat;
        }

        .brown-t {
            color: #d17b30;
        }

        .blue-t {
            color: #01789e;
        }

        .purple-t {
            color: #c3a9ff;
        }

        ul {

            text-decoration: none;
        }

        .navv li {
            text-decoration: none;
            /* text-decoration-color: transparent; */
            list-style-type:none;
            margin-top: 10px;
            border-bottom: 1px solid white;
        }

        .navv li a {
            color: white;
        }
        .activee{
            /* background-color: #d17b30; */
            /* color: red; */
            font-weight: 400;
        }
        #dis{
            background-color: transparent;
            border: 0px;
        }
        #dis:focus {
  border: 3px solid tomato;
  transform: scale(1.2);
}

.lg{
    background-color: #017e7e;
}
.lg-t{
    color: #017e7e;
}

.g{
    background-color: #045d5d;
}
.g-t{
    color: #045d5d;
}
.g-tt{
    color: #99d9d9;
}

    </style>
</head>

<body>

<div class="container-fluid " style="min-height: 90vh;background-color:whitesmoke">
    <div class="row  d-flex justify-content-center align-items-center " style="min-height: 90vh;">

        <div class="col-md-7  d-flex align-items-center justify-content-center    ">
            <div class="row shadow-lg rounded p-2 bg-white">
                <div class="col-5 p-5 ps-2 fs-3 g text-white d-flex align-items-center justify-content-center rounded">
                    <p class="mt-4"> </p>
                    <p class="text-center">Pay Rs. 100/- For Complete Your Registration</p>
                </div>
                <div class="col-7 p-5 fw-bold">
                    <form action="payscript.php" method="POST">
                        <label for="" class=" w-100">Name</label>
                        <input type="text" name="name" class="form-control bg-transparent border-success  border-bottom border-start-0 border-top-0 border-end-0 w-100" value="<?php echo $_SESSION['name'] ?>" disabled> <br>
                        <label for="" class=" w-100">Email</label>
                        <input type="text" name="name" class="form-control bg-transparent border-success  border-bottom border-start-0 border-top-0 border-end-0 w-100" value="<?php echo $_SESSION['email'] ?>" disabled> <br>
                        <label for="" class=" w-100">phone</label>
                        <input type="text" name="phone" class="form-control bg-transparent border-success  border-bottom border-start-0 border-top-0 border-end-0 w-100" value="<?php echo $_SESSION['phone'] ?>" disabled> <br>
                        <!-- <label for="" class=" w-100" >State</label>
    <input type="text" class="form-control bg-transparent border-success  border-bottom border-start-0 border-top-0 border-end-0 w-100"  value="<?php echo $_SESSION['state'] ?>" disabled> <br> -->
                        <label for="" class=" w-100">Center Name</label>
                        <input type="text" name="institutename" class="form-control bg-transparent border-success  border-bottom border-start-0 border-top-0 border-end-0 w-100" value="<?php echo $_SESSION['instituteName'] ?>" disabled> <br>
                        <input type="hidden" name="id" class="form-control bg-transparent border-success  border-bottom border-start-0 border-top-0 border-end-0 w-100" value="<?php echo $_SESSION['id'] ?>" disabled> <br>
                        <input type="submit" value="Pay 100 !" name="amount" class="form-control w-100">
                    </form>
                        <a href="logout.php" class="btn rounded-pill float-end btn-outline-success mt-5">LOGOUT</a>
                </div>
            </div>


        </div>
    </div>
</div>