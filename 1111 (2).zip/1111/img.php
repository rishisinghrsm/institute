<?php 
session_start();
include "config.php";
// $id = hex2bin($_GET['l']);
$reg = hex2bin($_GET['id']);
$sql = "SELECT payment,id,aadhar FROM newStudent WHERE regNo = {$reg} AND payment = 1";
$result = mysqli_query($conn,$sql) or die("death eeeeeeeeeee");
$row = mysqli_fetch_assoc($result);

if($row['payment'] != 1){
header("Location: showCertificate.php");
}
?>

<center>

    <img width="99%" src="institute-images/<?php echo $_SESSION['aadhar'] ?>/students/<?php echo $row['aadhar']."/".$reg."_".$row['id'] ?>.jpg" alt="">
    <!-- <a type="button" href="institute-images/<?php echo $_SESSION['aadhar'] ?>/students/<?php echo hex2bin($_GET['id']) ?>.jpg" download="<?php echo hex2bin($_GET['id']) ?>.jpg">Save</a> -->
    
<!-- <button style="border: 1px solid green ; padding:5px 11px 5px 11px;margin-top:20px;text-decoration:none;color:green"  onclick="window.print()">Print this Certificate</button> -->

</center>

<script>
    alert('To Print Or Save Press Ctrl + P !')
</script>