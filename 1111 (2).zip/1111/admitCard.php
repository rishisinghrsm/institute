<?php include 'headerInstitute.php' ?>


<?php
                    include 'config.php';
                    // $num = 1;
                    
                    $id = hex2bin($_GET['id']);
                    // $admitCardPath ="";
                    // session_start();
                    $sqlForStu = "SELECT * FROM `certificate`
                    left join newStudent on newStudent.id = certificate.studentId 
                    LEFT JOIN subSkill ON subSkill.id = certificate.subskill
                    WHERE certificate.id = {$id} ";
                    // $sqlForStu .= "UPDATE `certificate` SET `payment`='$admitCardPath' WHERE id = {$id}";
                    // $sqlForStu .= "UPDATE `certificate` SET `qr`='$file' WHERE id = $stuId";
                    // echo $sqlForStu;

                    $resultForStu = mysqli_query($conn, $sqlForStu) or die('Query Fail For Category');
                    while ($rowForStu = mysqli_fetch_assoc($resultForStu)) {
                        // $admitCardPath = $path.'admitCard/'.$rowForStu['regNo'].".txt";
                        // echo $admitCardPath;




                        $myfile = fopen('admitCard/'.$rowForStu['regNo'].".txt" , "w") or die("Unable to open file!");
$txt = "Student Name :- \t".$rowForStu['certificateHolder']."\nFather Name :- \t".$rowForStu['certificateHoldderFather']."\nRegistration Number :- \t".$rowForStu['regNo']."\nCourse :- \t".$rowForStu['subSkillName']."\nAdmition Date\t".$rowForStu['startingDate'];
fwrite($myfile, $txt);
// echo $txt;
fclose($myfile);






                      ?>
<div class="text-center fs-2 ">

    <a href="admitCard/<?php echo $rowForStu['regNo']?>.txt" class="text-center"  download>DOWNLOAD</a>
</div>
      
        <?php  };?>
 
        
