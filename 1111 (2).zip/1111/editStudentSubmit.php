<?php 
include 'config.php';

if(isset($_POST['submit'])){
    session_start();
    $id = $_POST['hidden'];
    // $hiddenImg = $_POST['hiddenImg'];
    // $hiddenImgName = $_POST['hiddenImgName'];
    // if(isset($_FILES['file'])){
        if(empty($_FILES['img1']['name'])){

            $file_name1 = $_POST['hiddenImgName'];
        }else{
        
            $file_name1 = $_FILES['img1']['name'];
            $file_size1 = $_FILES['img1']['size'];
            $file_temp1 = $_FILES['img1']['tmp_name'];
            $file_type1 = $_FILES['img1']['type'];
            move_uploaded_file($file_temp1,"institute-images/". $_SESSION["aadhar"] ."/students/". $file_name1);
        }
        
        
    // }else{
        
    //     $file_name1 = $hiddenImgName;
    //     // $file_name1 = $_FILES['img1']['name'];
    //     // $file_size1 = $_FILES['img1']['size'];
    //     $file_temp1 = $_FILES['img1']['tmp_name'];
    //     // $file_type1 = $_FILES['img1']['type'];
    //     move_uploaded_file($file_temp1,"institute-images/". $_SESSION["aadhar"] ."/students/". $file_name1);
    // }
// $img = $_FILES['file'];
$name = $_POST['name'];
$_SESSION['stuName'] = $name;
$fname = $_POST['fname'];
$_SESSION['fname'] = $fname;
$mname = $_POST['mname'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$aadhar = $_POST['aadhar'];
$gender = $_POST['gender'];
$state = $_SESSION['state'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$course = $_POST['course'];
$_SESSION['course'] = $course;
$date = date('d-m-y');
date_default_timezone_set('Asia/Kolkata');
$time = date("h:i:s");
$instituteId = $_SESSION['id'];

// $time=strtotime($date);
// $month=date("m",$time);
// $year=date("y",$time);
// global $regNo;
// $regNo = $state.$_SESSION['skill'].$month.$year.$instituteId;
// echo $date;
$sql = "UPDATE `newstudent` SET `name`='$name',`fname`='$fname',`mname`='$mname',`phone`='$phone',`email`='$email',`aadhar`=$aadhar,`gender`='$gender',`state`='$state',`address`='$address',`pincode`='$pincode',`course`='$course',`img`='$file_name1' WHERE id = $id";


                    $updateResult = mysqli_query($conn,$sql) or die("update fail");
                    header('Location:allStudent.php?submit=true');


                }else{
                    echo "error";
                }



















?>