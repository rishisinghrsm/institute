<?php
include "config.php";


if(isset($_POST['login'])){
    $phone =mysqli_real_escape_string($conn,$_POST['phone']);
    $pass = bin2hex($_POST['pass']);
    // $role = $_POST['role'];

    $sql = "SELECT id,phone,skill,instituteName,aadhar,institutePayment,state,name,pass,approve,email FROM institute WHERE phone = '{$phone}' AND pass = '{$pass}'";
   
    $result= mysqli_query($conn,$sql) or die("Query Fail");
    
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            session_start();
            
            $_SESSION["name"] = $row['name'];
            $_SESSION["phone"] = $row['phone'];
            $_SESSION["aadhar"] = $row['aadhar'];
            $_SESSION["email"] = $row['email'];
            $_SESSION["id"] = $row['id'];
            $_SESSION["skill"] = $row['skill'];
            $_SESSION["payment"] = $row['institutePayment'];
            $_SESSION["instituteName"] = $row['instituteName'];
            $_SESSION["state"] = $row['state'];
            $_SESSION["approve"] = $row['approve'];
            // echo $host;
            header("Location:". $path. "wait.php?a=".$row['approve']);
            
        }
    }else{
        echo "No User Found";
        header("Location:". $path. "form.php?submit=false");

    }
}else{
    echo "Login Fail";
}


?>