<?php include 'config.php';
include 'header.php' ?>

<div class="container-fluid " style="min-height: 90vh;background-color:whitesmoke">
    <div class="row  d-flex justify-content-center align-items-center " style="min-height: 90vh;">
        
        <div class="col-md-7  d-flex align-items-center justify-content-center    " >
            <div class="row shadow-lg rounded p-2 bg-white">
                <div class="col-4 p-5 ps-2 fs-3 g text-white rounded">
                    <p class="mt-4">DOCUMENT </p>
                    <p >VERIFICATION !</p>
                </div>
                <div class="col-8 p-5 fw-bold">
                <form action="documentSubmit.php" method="post">
                   
                <label for="">ENTER REGISTRATION NUMBER / CERTIFICATE NUMBER :  </label>
                <input type="text" name="no"  required class="form-control mt-3">
                <!-- <label for="">ENTER AADHAR NUMBER : </label>
                <input type="text" name="aadhar" minlength="12" maxlength="12" required class="form-control mt-3"> -->
                <?php if(isset($_GET['submit'] )){
                        if($_GET['submit'] == 'wrong'){

                            echo '<small class="text-danger">WRONG REGISTRATION NUMBER / CERTIFICATE NUMBER , <br> PLEASE ENTER AGAIN !</small>';
                        }else if($_GET['submit'] == 'due'){

                            echo '<small class="text-danger">PAYMENT IS DUE ! PLEASE CLEAR YOUR PAYMENT BEFORE VERIFICATION !</small>';
                        };
                    } ?>
                <input type="submit" value="SUBMIT" name="submit" class="form-control mt-3 g text-white">
            </form>
                </div>
            </div>

            
        </div>
    </div>
</div>