
<?php include 'config.php';

session_start();
if(isset($_SESSION["phone"])){
     header('Location: '.$path.'instituteDashboard.php');
}



?>

<?php include 'config.php';
include 'header.php' ?>

<div class="container-fluid " style="min-height: 90vh;background-color:whitesmoke">
    <div class="row  d-flex justify-content-center align-items-center " style="min-height: 90vh;">
        
        <div class="col-md-10  d-flex align-items-center justify-content-center    " >
            <div class="row w-50 shadow-lg rounded p-2 bg-white">
                <div class="col-4 p-5 ps-2 fs-3 g text-white rounded">
                    <p class="mt-4">CENTER </p>
                    <p >LOGIN !</p>
                </div>
                <div class="col-8 p-4 fw-bold">
                    
                     <?php 
        if(isset($_GET['submit']) == "generated"){
            echo " <script>
UIkit.notification('Wrong Username Or Password !');
        </script>";
        }

        ?>
                <form action="formSubmit.php" method="post">
                <label class=" g-t mt-4">&nbsp; Phone Number</label>
                <input type="text" name="phone" id=" " maxlength="10" minlength="10" class="form-control inputDesign w-100 mt-2 bg-transparent g-t" placeholder="Enter Your Phone Number !">
                <label class=" g-t mt-4">&nbsp; Password</label>
                <input type="password" name="pass" id=" " minlength="8" maxlength="10" class="form-control w-100 mt-2 bg-transparent g-t" placeholder="Enter Your Password !">
                <a href="forgot.php" class="text-dark-emphasis">FORGOT PASSWORD ?</a>
                <input type="submit" name="login" value="LOGIN !" id=" " class="form-control  w-100 mt-2 bg-transparent g-t" placeholder="Enter Your Username !">
            </form>
                </div>
            </div>

           
        </div>
    </div>
</div>