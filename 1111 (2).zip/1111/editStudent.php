<?php include "headerInstitute.php";


?>
<?php include 'qr/phpqrcode/qrlib.php';  

// date_default_timezone_set('Asia/Kolkata');
// $date = date("l jS \of F Y h:i:s A");
// // $date = date("dmy ");
// echo $date;
// // $t = time();
// $t = date_default_timezone_get();
// $text = "Dhananjay ISngh"; 
// // $pixel_Size=30;
// $pixel_Size = 10; 
// $frame_Size = 10; 
// $path = 'qr/generatedQr/ ';

// $file = $path.uniqid().".png"; 
// // QR Code generation using png() 
// // When this function has only the 
// // text parameter it directly 
// // outputs QR in the browser 
// QRcode::png($text,$file, $pixel_Size, $frame_Size); 
// echo "<center><img src='".$file."'></center>";

?>




<div class="container">

<?php
$id = $_GET['id'];
$sql = "SELECT * FROM newStudent
        left join subSkill on subskill.id = newStudent.course
         WHERE newStudent.id = $id AND institute = {$_SESSION['id']} AND payment = 0";
$result= mysqli_query($conn,$sql) or die("death");
$row = mysqli_fetch_assoc($result);

?>
    <form action="editStudentSubmit.php" method="post" enctype="multipart/form-data">
        <div class="row lg p-5 mt-5">
        <p class="fs-3 text-white border-bottom " style="text-shadow: 4px 4px 10px black;">ADD NEW STUDENT</p>
        <div class="col-4">
        <label class=" text-white mt-4 ">&nbsp;Passport Size Photo</label><br>
        
        <img src="institute-images/<?php echo $_SESSION['aadhar'].'/'.'students/'. $row['img'] ?>" style="max-width: 100px;max-height:120px;width: 100px;height: 120px; " alt="">
        <input type="file" value="institute-images/<?php echo $_SESSION['aadhar'].'/'.'students/'. $row['img'] ?>" accept="image/jpeg,image/png,image/jpg,image/PNG,image/JPEG,image/JPG" name="img1" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Name !">
        <input type="hidden" name="hiddenImgName" value="<?php echo $row['img'] ?>">
        </div>
        <div class="col-4">
    <label class=" text-white mt-4">&nbsp; Name</label>
    <input type="text" name="name" id=" " value="<?php echo $row['name'] ?>" class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Name !">
    </div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Father's Name</label>
<input type="text" name="fname" id=" " value="<?php echo $row['fname'] ?>" class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Father's Name !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Mother's Name</label>
                <input type="text" name="mname" value="<?php echo $row['mname'] ?>" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Mother's Name !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Phone Number</label>
<input type="number" name="phone" id=" " value="<?php echo $row['phone'] ?>" class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Phone Number !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Aadhar Number</label>
<input type="number" name="aadhar" id=" " value="<?php echo $row['aadhar'] ?>" class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Phone Number !">
</div>
<div class="col-4">

<label class=" text-white mt-4">&nbsp; Email</label>
                <input type="email" name="email" value="<?php echo $row['email'] ?>" id=" " class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Email !">
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Gender</label>
                <select name="gender" id="" class="form-control w-75" required>
                    <option value="<?php echo $row['gender'] ?>" selected disabled>
                        <?php  if($row['gender'] == 'f' ){
                            echo "Female";
                        }else{
                            echo "Male";
                        }
                            ?>
                    </option>
                    <option value="m">Male</option>
                    <option value="f">Female</option>
                </select>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Address</label>
<textarea name="address" id="" class="form-control w-75 mt-2 bg-transparent text-white"><?php echo $row['address'] ?></textarea>
<!-- <input type="text" name="" id=" " value="" class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Address !"> -->
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Pincode</label>
<input type="text" name="pincode" id=" " value="<?php echo $row['pincode'] ?>" class="form-control w-75 mt-2 bg-transparent text-white" placeholder="Enter Your Pincode !">
</div>
<div class="col-4">
    <label class=" text-white mt-4">&nbsp; SESSION</label><br>
    <select name="year" id="" class="form-control w-75 mt-2 " disabled>
        <option value="<?php echo $row['yearOfAdmission'] ?>" selected disabled><?php echo $row['yearOfAdmission']."-".$row['yearOfAdmission']+1 ?></option>
        <option value="2010">2010-2011</option>
        <option value="2011">2011-2012</option>
        <option value="2012">2012-2013</option>
        <option value="2013">2013-2014</option>
        <option value="2014">2014-2015</option>
        <option value="2015">2015-2016</option>
        <option value="2016">2016-2017</option>
        <option value="2017">2017-2018</option>
        <option value="2018">2018-2019</option>
        <option value="2019">2019-2020</option>
        <option value="2020">2020-2021</option>
        <option value="2021">2021-2022</option>
        <option value="2022">2022-2023</option>
        <option value="2023">2023-2024</option>
        <option value="2024">2024-2025</option>
       
        
    </select>
</div>
<div class="col-4">
<label class=" text-white mt-4">&nbsp; Course</label>
                <select name="course" id="" class="form-control w-75">
                    <!-- <option value="0" disabled>Select</option> -->
                    <option selected  value="<?php echo $row['course'] ?>"><?php echo $row['subSkillName'] ?></option>
                    <?php 
                    include 'config.php';
                    $sqlSubSkill = "SELECT subSkillName,skillUnder,id FROM subSkill WHERE skillUnder = {$_SESSION['skill']}";
                    $resultSubSkill = mysqli_query($conn, $sqlSubSkill) or die('Query Fail For Category');
                    while ($rowSubSkill = mysqli_fetch_assoc($resultSubSkill)) {
                    ?>
                        <option value="<?php echo $rowSubSkill['id'] ?>"><?php echo $rowSubSkill['subSkillName'] ?></option>
                    <?php }; ?>
                   
                   
                   
                </select>
</div>
<div class="col-12">
<input type="hidden" name="hidden" value="<?php echo $_GET['id'] ?>" id=" " class="form-control  w-50 m-auto mt-2 bg-transparent text-white" >
<input type="hidden" name="hiddenImg" value="institute-images/<?php echo $_SESSION['aadhar'].'/'.'students/'. $row['img'] ?>" id=" " class="form-control  w-50 m-auto mt-2 bg-transparent text-white" >
<input type="submit" name="submit" value="Submit !" id=" " class="form-control  w-50 m-auto mt-2 bg-transparent text-white" >

</div>

</form>






      
    </div>
</div>


<?php include 'instituteFooter.php' ?>