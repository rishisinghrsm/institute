

                    <?php
                    include 'config.php';
                    if(isset($_POST['submit'])){
                    $phone = $_POST['phone'];
                    $aadhar = $_POST['aadhar'];

                    $sql  ="SELECT id,aadhar,phone FROM institute WHERE aadhar = $aadhar AND phone = $phone";
                    $result= mysqli_query($conn,$sql) or die('dead');
                       
                         $row = mysqli_fetch_assoc($result);
                         print_r($row);
                            echo $aadhar;
                            echo $phone;
                            if($row['aadhar'] == $aadhar && $row['phone'] == $phone){
                                
                                header("Location: ".$path."reset.php?id=".bin2hex($row['id']));
                            }else{
                                header("Location: ".$path."forgot.php?submit=wrong");
                                
                            };
                        

                    }else{
                      echo 'error'; 
                    }
                    ?>
                