<?php include "header.php"; ?>
<?php include 'qr/phpqrcode/qrlib.php';

// date_default_timezone_set('Asia/Kolkata');
// $date = date("l jS \of F Y h:i:s A");
// // $date = date("dmy ");
// echo $date;
// // $t = time();
// $t = date_default_timezone_get();
// $text = "Dhananjay ISngh"; 
// // $pixel_Size=30;
// $pixel_Size = 10; 
// $frame_Size = 10; 
// $path = 'qr/generatedQr/ ';

// $file = $path.uniqid().".png"; 
// // QR Code generation using png() 
// // When this function has only the 
// // text parameter it directly 
// // outputs QR in the browser 
// QRcode::png($text,$file, $pixel_Size, $frame_Size); 
// echo "<center><img src='".$file."'></center>";

?>

<script type="text/javascript">
        window.history.forward();
        function noBack() {
            window.history.forward();
        }
    </script>


<div class="container p-5 mt-4 lg g-t">
    <form action="newInstituteSubmit.php" method="post" enctype="multipart/form-data">
        <p class="big text-white fw-bold" style="text-shadow: 4px 4px 5px black;">&nbsp;Get Your Franchise !</p>
        <div class="row p-5 shadow-lg bg-white" style="backdrop-filter: blur(15x);">
            <div class="text-danger border-bottom">

                <h3 class="g-t  ">PERSONAL DETAILS !</h3>
            </div>
            <div class="col-md-4  ">
                <label class=" g-t mt-4">&nbsp; Your Name<span class=" text-danger">*</span></label>
                <input type="text" name="name" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Enter Your Name !">
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Passport size photo<span class=" text-danger">*</span></label>
                <span>

                    <input type="file" name="pimg" id="file-input-4" class="form-control w-75 mt-2 bg-transparent g-t" placeholder="Enter Your Father's Name !" accept="image/png, image/jpeg  ,image/jpg">
                </span>
                <span>
                    <script type="text/javascript">
                        $('#file-input-4').bind('change', function() {
                            // alert('Hi');
                            if (this.files[0].size < 300000) {



                                const input = document.getElementById('file-input-4');
                                const previewPhoto = () => {
                                    const file = input.files;
                                    if (file) {
                                        const fileReader = new FileReader();
                                        const preview = document.getElementById('file-preview');
                                        fileReader.onload = function(event) {
                                            preview.setAttribute('src', event.target.result);
                                        }
                                        fileReader.readAsDataURL(file[0]);
                                        $('#submit').css('display', 'inline');
                                    }
                                }
                                input.addEventListener("focusout", previewPhoto);
                                document.getElementById('size').innerHTML =
                                    '<b>' + file + '</b> KB';
                            } else {

                                alert('This file size is more then 300KB ! Please select less then 300KB !  ');
                                $('#submit').css('display', 'none');


                            }
                        });
                    </script>
                </span>
            </div>
            <div class="col-md-4  ">
                <label class=" g-t mt-4">&nbsp; Image Preview</label><br>
                <div class="m-auto text-center">

                    <img src="#" alt="" class=" w-70   border" id="file-preview" style="max-width: 130px;max-height :160px;min-width:130px;min-height:160px">
                    <p id="size"> </p>
                </div>

            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Aadhar/Pan Number<span class=" text-danger">*</span></label>
                <input type="text" minlength="12" maxlength="12" id='aadhar' name="aadhar" class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Enter Your Aadhar Number ! !">
                <p id="aa"></p>

            </div>
            <div class="col-md-4 aadharV ">

                <label class=" g-t mt-4">&nbsp; Aadhar Front / Pancard Front<span class=" text-danger">*<small> Should Be Less Then 300KB !</small></span></label>
                <input type="file" name="aadharFront" id="file-input5" onchange="Filevalidation5()" accept="image/png, image/jpeg ,image/jpg" class="form-control w-75 mt-2 bg-transparent g-t" required>
            </div>
            <script type="text/javascript">
                $('#file-input5').bind('change', function() {
                    // alert('Hi');
                    if (this.files[0].size > 300000) {



                        alert('This file size is more then 300KB ! Please select less then 300KB !  ');
                        $('#submit').css('display', 'none');

                    } else {

                        $('#submit').css('display', 'inline');


                    }
                });
            </script>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Aadhar back <span class=" text-danger"> <small> Should Be Less Then 300KB !</small></span></label>
                <input type="file" name="aadharBack" id="file-input6" onchange="Filevalidation2()" accept="image/png, image/jpeg ,image/jpg" class="form-control w-75 mt-2 bg-transparent g-t">
            </div>
            <script type="text/javascript">
                $('#file-input6').bind('change', function() {
                    // alert('Hi');
                    if (this.files[0].size > 300000) {



                        alert('This file size is more then 300KB ! Please select less then 300KB !  ');
                        $('#submit').css('display', 'none');

                    } else {

                        $('#submit').css('display', 'inline');


                    }
                });
            </script>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Father's Name<span class=" text-danger">*</span></label>
                <input type="text" name="fname" id=" " class="form-control w-75 mt-2 bg-transparent g-t" placeholder="Enter Your Father's Name !" required>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Date Of Birth <span class=" text-danger">* </span></label>
                <input type="date" name="dob" id="dob" class="form-control w-75 mt-2 bg-transparent g-t" placeholder="Enter Your Father's Name !" required>
            </div>
            <script>
                var todaysDate = new Date(); // Gets today's date
               
                // Max date attribute is in "YYYY-MM-DD".  Need to format today's date accordingly
               
                var year = todaysDate.getFullYear(); // YYYY
                var year1 = year -18;
                
               
                var month = ("0" + (todaysDate.getMonth() + 1)).slice(-2); // MM
               
                var day = ("0" + todaysDate.getDate()).slice(-2); // DD
               
                var maxDate = (year1 + "-" + month + "-" + day); // Results in "YYYY-MM-DD" for today's date 
               
                // Now to set the max date value for the calendar to be today's date
                
                $('#dob').attr('max', maxDate);
            </script>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Gender<span class=" text-danger">*</span></label>
                <select name="gender" id="" required class="form-control w-75">
                    <option value="0" selected disabled>Select</option>
                    <option value="m">Male</option>
                    <option value="f">Female</option>
                </select>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Education Qualifiction <span class=" text-danger">* </span></label>
                <select name="education" id="" required class="form-control w-75">
                    <option value="0" selected disabled>Select</option>
                    <option value="10th Pass">10th Pass</option>
                    <option value="12th Pass">12th Pass</option>
                    <option value="Graduate">Graduate</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Phone Number ( It will be your Username )<span class=" text-danger">*</span></label>
                <input type="text" name="phone" maxlength="10" id="field_1" class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Enter Your Phone Number !">
                <p id="pp"></p>
            </div>
            <!-- <script>
                
                $("#field_1").on("keydown",function(){
                        var phone = $('#field_1').val();

                   
                    $.ajax({
                            url: "newInstituteSubmit.php",
                            type: "POST",
                            data: {
                                p: phone
                            },
                            success: function(data) {
                                if (data === 'USER_EXISTS') {
                                    $('#num')
                                        .css('color', 'red')
                                        .html("This phone number is already exists!");
                                }else if(data == 'USER_EXISTS'){
                                    $('#num')
                                    .css('color', 'red')
                                    .html("error");
                                }

                            }
                        })

                    })
                   
            </script> -->
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Email<span class=" text-danger">*</span></label>
                <input type="email" name="email" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Enter Your Email !">
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Address<span class=" text-danger">*</span></label>
                <textarea type="email" name="address" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Enter Your Address !"></textarea>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; State<span class=" text-danger">*</span></label>
                <select name="state" id="" class="form-control w-75" required>
                    <option value="0" selected disabled>Select</option>
                    <?php
                    include 'config.php';
                    $sqlState = "SELECT stateId,stateName FROM state";
                    $resultState = mysqli_query($conn, $sqlState) or die('Query Fail For Category');
                    while ($rowState = mysqli_fetch_assoc($resultState)) {
                    ?>
                        <option value="<?php echo $rowState['stateId'] ?>"><?php echo $rowState['stateName'] ?></option>
                    <?php }; ?>
                </select>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Pincode<span class=" text-danger">*</span></label>
                <input type="text" name="pincode" id=" " maxlength="6"  class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Enter Your Pincode !">
            </div>

        </div>
        <!-- -------------------------------intitute details ------------------------------------------------ -->
        <!-- <p class="big text-white fw-bold" style="text-shadow: 4px 4px 5px black;">&nbsp;Center Details !</p> -->
        <div class="row p-5 mt-5 shadow-lg bg-white" style="backdrop-filter: blur(15x);">


            <div class="text-danger border-bottom">

                <h3 class=" g-t mt-4">CENTER DETAILS !</h3>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Select Skill<span class=" text-danger">*</span></label>
                <select name="skill" id="" class="form-control w-75" required>
                    <option value="0" selected disabled>Select</option>
                    <?php
                    include 'config.php';
                    $sqlSkill = "SELECT skills,id FROM skills";
                    $resultSkill = mysqli_query($conn, $sqlSkill) or die('Query Fail For Category');
                    while ($rowSkill = mysqli_fetch_assoc($resultSkill)) {
                    ?>
                        <option value="<?php echo $rowSkill['id'] ?>"><?php echo $rowSkill['skills'] ?></option>
                    <?php }; ?>

                </select>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Institute's Name<span class=" text-danger">*</span></label>
                <input type="text" name="institutenamme" required id=" " class="form-control w-75 mt-2 bg-transparent g-t" placeholder="Enter Your Institute's Name !">
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Institute Address<span class=" text-danger">*</span></label>
                <textarea type="text" name="address" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Enter Center Your Address !"></textarea>

            </div>

            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; State<span class=" text-danger">*</span></label>
                <select name="state" id="" required class="form-control w-75">
                    <option value="0" selected disabled>Select</option>
                    <?php
                    include 'config.php';
                    $sqlState = "SELECT stateId,stateName FROM state";
                    $resultState = mysqli_query($conn, $sqlState) or die('Query Fail For Category');
                    while ($rowState = mysqli_fetch_assoc($resultState)) {
                    ?>
                        <option value="<?php echo $rowState['stateId'] ?>"><?php echo $rowState['stateName'] ?></option>
                    <?php }; ?>
                </select>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; District<span class=" text-danger">*</span></label>
                <input type="text" name="district" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="District Name  !">
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Pincode<span class=" text-danger">*</span></label>
                <input type="text" name="" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Pincode  !">
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Center Area <span class=" text-danger">(in Sq Ft )*</span></label>
                <input type="text" name="centerArea" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Center Area !">
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Number of Class Room ?<span class=" text-danger">*</span></label>
                <input type="text" name="noOfClassRoom" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="Number of Class Room ?">
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Currently Total No. Of Student ?<span class=" text-danger">*</span></label>
                <input type="text" name="noOfStudent" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder=" Currently Total No. Of Student ?  !">
            </div>
            <!-- <div class="col-md-4  ">

                <p id=""></p>
                <textarea name="location" id="demo" class="form-control w-75 " disabled></textarea>
                <button class="btn btn-outline-dark w-75 mt-4" onclick="getLocation()">GET YOUR LOCATION</button>
                <br>
        </div> -->
            <!-- <label class=" g-t mt-4">&nbsp; Number of Computer ?<span class=" text-danger">*</span></label>
                <input type="text" name="noOfComputer" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="No Of Computer Working !"> -->
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Number of Teachers ?<span class=" text-danger">*</span></label>
                <input type="text" name="noOfTeacher" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="No of Teachers  !">
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Air Conditining</label><br>
                <select name="airCondining" id="" class="form-control w-75">
                    <option value="0" selected>No</option>
                    <option value="1">Yes</option>
                </select>
                <!-- <input type="text" name="address" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="No of Teachers  !"> -->
            </div>

            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp;Power Backup Avalable ?</label>
                <select name="powerBackup" id="" class=" form-control w-75">
                    <option value="0" selected>NO</option>
                    <option value="1" selected>YES</option>
                </select>
                <!-- <input type="text" name="address" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="No of Teachers  !"> -->
            </div>
            <div class="col-md-4  ">
                <label class=" g-t mt-4">&nbsp;Washroom</label><br>
                <select name="" id="" class="form-control w-75">
                    <option value="0" selected>No</option>
                    <option value="1">Yes</option>
                </select>
                <!-- <input type="text" name="address" id=" " class="form-control w-75 mt-2 bg-transparent g-t" required placeholder="No of Teachers  !"> -->
            </div>

            <div class="text-danger border-bottom">
                <h3 class="g-t  mt-4">CENTER PICTURES !
                    <small class="text-danger fs-6">( Images Should be less then or equal to 500KB and should be png or jpeg ) </small>

                </h3>
            </div>
            <br>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; From Front <span class=" text-danger">*</span></label>
                <input type="file" accept="image/png, image/jpeg  ,image/jpg" name="img1" id="file-input1" class="form-control w-75 mt-4" required>
                <p id="size1"></p>
                <script type="text/javascript">
                    $('#file-input1').bind('change', function() {
                        // alert('Hi');
                        if (this.files[0].size > 300000) {



                            alert('This file size is more then 300KB ! Please select less then 300KB !  ');
                            $('#submit').css('display', 'none');

                        } else {

                            $('#submit').css('display', 'inline');


                        }
                    });
                </script>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Inside Picture From First Corner<span class=" text-danger">*</span></label>
                <input type="file" accept="image/png, image/jpeg ,image/jpg" name="img2" id="file-input2" class="form-control w-75 mt-4" required>
                <p id="size2"></p>
                <script type="text/javascript">
                    $('#file-input2').bind('change', function() {
                        // alert('Hi');
                        if (this.files[0].size > 300000) {



                            alert('This file size is more then 300KB ! Please select less then 300KB !  ');
                            $('#submit').css('display', 'none');

                        } else {

                            $('#submit').css('display', 'inline');


                        }
                    });
                </script>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Inside Picture From Second Corner<span class=" text-danger">*</span></label>
                <input type="file" accept="image/png, image/jpeg  ,image/jpg" name="img3" id="file-input3" class="form-control w-75 mt-4">
            </div>
            <script type="text/javascript">
                $('#file-input3').bind('change', function() {
                    // alert('Hi');
                    if (this.files[0].size > 300000) {



                        alert('This file size is more then 300KB ! Please select less then 300KB !  ');
                        $('#submit').css('display', 'none');

                    } else {

                        $('#submit').css('display', 'inline');


                    }
                });
            </script>
            <!-- <input type="file" accept="image/png, image/jpeg " name="img4" id="" class="form-control w-75 mt-4"> -->
            <br>
        </div>
        <div class="row p-5 mt-5 shadow-lg bg-white" style="backdrop-filter: blur(15x);">

            <div class="text-danger border-bottom">
                <h3 class="g-t  mt-4">USERNAME AND PASSWORD ! </h3>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Username <span class=" text-danger">*</span></label>
                <input type="text" name="pass" id="field_2" class="form-control w-75 mt-2 bg-transparent g-t " required placeholder="Enter Your Username !" disabled> <br>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Create a Password <span class=" text-danger">*</span></label>
                <input type="password" name="pass" id="pass" class="form-control w-75 mt-2 bg-transparent g-t validate password" required placeholder="Enter Your Password !"> <span class="togglePassword text-danger-50">Show Password</span> <br>
            </div>
            <div class="col-md-4  ">

                <label class=" g-t mt-4">&nbsp; Conform Password <span class=" text-danger">*</span></label>
                <input type="password" name="pass" id="conf" class="form-control w-75 mt-2 bg-transparent g-t validate passwordConfirm" required placeholder="Enter Your Password !">
            </div>
            <div class="col-md-4  "></div>
            <div class="col-md-4  ">
                <div id="password_rules">
                    <h4 class="text-danger-50">Passwords must meet these requirements:</h4>
                    <ul class="">
                        <li class="password_length">At least 8 characters</li>
                        <li class="password_uppercase">At least 1 uppercase letter</li>
                        <li class="password_number">at least one number</li>
                        <li class="password_match">password and confirmation must match</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4  "></div>
            <div class="col-md-12  ">


                <input type="submit" name="submit" value="Submit !" id="submit" class=" btn rounded-pill " style="padding: 10px 10px ;width:100px;height:50px;background-color:#017171;border:0px;color:white;font-weight:800 ;float:right">
            </div>
        </div>

</div>
</form>
</div>

<script>
    $(document).ready(function() {
        $('#aadhar').blur(function() {
            var aadhar = $('#aadhar').val();

            $.ajax({
                url: 'aadharCheck.php',
                method: 'POST',
                data: {
                    aadhar_no: aadhar
                },
                success: function(data) {
                    if (data != 0) {
                        $('#aa').html('Already Used Before, Please Enter New No !');
                        $('#aa').css('color', "red");
                        // $('input[type="text"]').attr("disabled", 'disabled');
                        $('#submit').css('display', 'none');
                    } else {
                        $('#aa').html(' ');
                        $('#submit').css('display', 'inline');
                    }
                }
            })
        })

    })
</script>
<script>
    $(document).ready(function() {
        $('#field_1').blur(function() {
            var field_1 = $('#field_1').val();

            $.ajax({
                url: 'numCheck.php',
                method: 'POST',
                data: {
                    phone_no: field_1
                },
                success: function(data) {
                    if (data != 0) {
                        $('#pp').html('Already Used Before, Please Enter New No !');
                        $('#pp').css('color', "red");
                        $('#submit').css('display', 'none');
                    } else {
                        $('#pp').html(' ');
                        $('#submit').css('display', 'inline');
                    }
                }
            })
        })

    })
</script>
<script>
    Filevalidation = () => {
        const fi = document.getElementById('file-input-4');
        // Check if any file is selected.
        if (fi.files.length > 0) {
            for (const i = 0; i <= fi.files.length - 1; i++) {

                const fsize = fi.files.item(i).size;
                const file = Math.round((fsize / 1024));
                // The size of the file.
                if (file >= 1024) {
                    alert(
                        "File too Big, please select a file less than 1mb");
                    document.getElementById('size').innerHTML =
                        '<p class="text-danger fw-bolder"><b>Your File Size is ' + file + '</b> KB Please . Select a file Less Then 1 MB !</p>';
                } else if (file < 1024) {

                } else {
                    document.getElementById('size').innerHTML =
                        '<b>' + file + '</b> KB error';

                }
            }
        }
    }
    Filevalidation1 = () => {
        const fi = document.getElementById('file-input1');
        // Check if any file is selected.
        if (fi.files.length > 0) {
            for (const i = 0; i <= fi.files.length - 1; i++) {

                const fsize = fi.files.item(i).size;
                const file = Math.round((fsize / 1024));
                // The size of the file.
                if (file >= 1024) {
                    alert(
                        "File too Big, please select a file less than 1mb");
                    document.getElementById('size1').innerHTML =
                        '<p class="text-danger fw-bolder"><b>Your File Size is ' + file + '</b> KB Please . Select a file Less Then 1 MB !</p>';
                } else {
                    document.getElementById('size1').innerHTML =
                        ' ';

                }
            }
        }
    }
    Filevalidation2 = () => {
        const fi = document.getElementById('file-input2');
        // Check if any file is selected.
        if (fi.files.length > 0) {
            for (const i = 0; i <= fi.files.length - 1; i++) {

                const fsize = fi.files.item(i).size;
                const file = Math.round((fsize / 1024));
                // The size of the file.
                if (file >= 1024) {
                    alert(
                        "File too Big, please select a file less than 500kb");
                    document.getElementById('size2').innerHTML =
                        '<p class="text-danger fw-bolder"><b>Your File Size is ' + file + '</b> KB Please . Select a file Less Then 500kb !</p>';
                } else {
                    document.getElementById('size2').innerHTML =
                        ' ';

                }
            }
        }
    }
    Filevalidation3 = () => {
        const fi = document.getElementById('file-input3');
        // Check if any file is selected.
        if (fi.files.length > 0) {
            for (const i = 0; i <= fi.files.length - 1; i++) {

                const fsize = fi.files.item(i).size;
                const file = Math.round((fsize / 1024));
                // The size of the file.
                if (file >= 1024) {
                    alert(
                        "File too Big, please select a file less than 500kb");
                    document.getElementById('size2').innerHTML =
                        '<p class="text-danger fw-bolder"><b>Your File Size is ' + file + '</b> KB Please . Select a file Less Then 500kb !</p>';
                } else {
                    document.getElementById('size2').innerHTML =
                        ' ';

                }
            }
        }
    }
    Filevalidation4 = () => {
        const fi = document.getElementById('file-input4');
        // Check if any file is selected.
        if (fi.files.length > 0) {
            for (const i = 0; i <= fi.files.length - 1; i++) {

                const fsize = fi.files.item(i).size;
                const file = Math.round((fsize / 1024));
                // The size of the file.
                if (file >= 1024) {
                    alert(
                        "File too Big, please select a file less than 500kb");
                    document.getElementById('size2').innerHTML =
                        '<p class="text-danger fw-bolder"><b>Your File Size is ' + file + '</b> KB Please . Select a file Less Then 500kb !</p>';
                } else {
                    document.getElementById('size2').innerHTML =
                        ' ';

                }
            }
        }
    }
    Filevalidation5 = () => {
        const fi = document.getElementById('file-input5');
        // Check if any file is selected.
        if (fi.files.length > 0) {
            for (const i = 0; i <= fi.files.length - 1; i++) {

                const fsize = fi.files.item(i).size;
                const file = Math.round((fsize / 1024));
                // The size of the file.
                if (file >= 1024) {
                    alert(
                        "File too Big, please select a file less than 500kb");
                    document.getElementById('size2').innerHTML =
                        '<p class="text-danger fw-bolder"><b>Your File Size is ' + file + '</b> KB Please . Select a file Less Then 500kb !</p>';
                } else {
                    document.getElementById('size2').innerHTML =
                        ' ';

                }
            }
        }
    }
    Filevalidation6 = () => {
        const fi = document.getElementById('file-input6');
        // Check if any file is selected.
        if (fi.files.length > 0) {
            for (const i = 0; i <= fi.files.length - 1; i++) {

                const fsize = fi.files.item(i).size;
                const file = Math.round((fsize / 1024));
                // The size of the file.
                if (file >= 1024) {
                    alert(
                        "File too Big, please select a file less than 500kb");
                    document.getElementById('size2').innerHTML =
                        '<p class="text-danger fw-bolder"><b>Your File Size is ' + file + '</b> KB Please . Select a file Less Then 500kb !</p>';
                } else {
                    document.getElementById('size2').innerHTML =
                        ' ';

                }
            }
        }
    }







    $(document).ready(function() {
        var validateInput = $('input.validate');

        function validateInputs() {
            var password = $('#pass').val(),
                conf = $('#conf').val(),
                all_pass = true;

            var uppercase = password.match(/[A-Z]/),
                number = password.match(/[0-9]/);

            if (password.length < 8) {
                $('.password_length').removeClass('complete');
                all_pass = false;
            } else $('.password_length').addClass('complete');

            if (uppercase) $('.password_uppercase').addClass('complete');
            else {
                $('.password_uppercase').removeClass('complete');
                all_pass = false;
            }

            if (number) $('.password_number').addClass('complete');
            else {
                $('.password_number').removeClass('complete');
                all_pass = false
            }


            if (password == conf && password != '') {

                $('.password_match').addClass('complete');
                $('#submit').css('display', 'inline');
            } else {
                $('.password_match').removeClass('complete')
                all_pass = false;
                $('#submit').css('display', 'none');
            }
        }
        validateInput.each(validateInputs).on('keyup', validateInputs);

        function showPassword() {
            if (validateInput.attr('type') === 'password') {
                validateInput.attr('type', 'text');
            } else if (validateInput.attr('type') === 'text') {
                console.log('else');
                validateInput.attr('type', 'password');
            }
        }
        $('.togglePassword').on('click', showPassword);
    });
    // --------------------------------------------------------------------------
    const x = document.getElementById("demo");

    function getLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition, showError);
        } else {
            x.innerHTML = "Geolocation is not supported by this browser.";
        }
    }

    function showPosition(position) {
        x.innerHTML = "Latitude: " + position.coords.latitude +
            "\nLongitude: " + position.coords.longitude;
    }

    function showError(error) {
        switch (error.code) {
            case error.PERMISSION_DENIED:
                x.innerHTML = "User denied the request for Geolocation."
                break;
            case error.POSITION_UNAVAILABLE:
                x.innerHTML = "Location information is unavailable."
                break;
            case error.TIMEOUT:
                x.innerHTML = "The request to get user location timed out."
                break;
            case error.UNKNOWN_ERROR:
                x.innerHTML = "An unknown error occurred."
                break;
        }
    }
</script>
<script type="text/javascript">
    $(document).ready(function() {
        function onchange() {
            //Since you have JQuery, why aren't you using it?
            var box1 = $('#field_1');
            var box2 = $('#field_2');
            box2.val(box1.val());
        }
        $('#field_1').on('change', onchange);
    });
</script>
<?php include 'footer.php' ?>