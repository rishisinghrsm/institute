
<!-- footer -->
<div class="container-fluid mt-5">
    <div class="row ">
        <div class="col-md-6 text-center" style="background-color: #01789e;">
            <img src="images/logo.png" width="130px" alt="" class="m-auto  mt-4 mb-4">
            <!-- <header class="text-white" style="font-size: 6px;">NATIONAL INSTITUTE OF SKILLS AND COMPUTING LTD. PVT.</header>
            <header class="text-white" style="font-size: 10px;">NATIONAL INSTITUTE OF SKILLS AND COMPUTING LTD. PVT.</header>
            <header class="text-white" style="font-size: 15px;">NATIONAL INSTITUTE OF SKILLS AND COMPUTING LTD. PVT.</header>
            <header class="text-white" style="font-size: 20px;">NATIONAL INSTITUTE OF SKILLS AND COMPUTING LTD. PVT.</header> -->

            <header class="text-white big mb-5" style="font-size: 26px;">NATIONAL INSTITUTE OF SKILLS AND COMPUTING LTD. PVT.</header>

            <!-- <header class="text-white" style="font-size: 20px;">NATIONAL INSTITUTE OF SKILLS AND COMPUTING LTD. PVT.</header>
            <header class="text-white" style="font-size: 15px;">NATIONAL INSTITUTE OF SKILLS AND COMPUTING LTD. PVT.</header>
            <header class="text-white" style="font-size: 10px;">NATIONAL INSTITUTE OF SKILLS AND COMPUTING LTD. PVT.</header>
            <header class="text-white" style="font-size: 6px;">NATIONAL INSTITUTE OF SKILLS AND COMPUTING LTD. PVT.</header> -->
        </div>
        <div class="col-md-3 p-5" style="background-color:#d17b30;">
            <ul class="big fs-4 text-white ">
                <li>HOME</li>
                <li>ABOUT US</li>
                <li>COURCES</li>
                <li>INSTITUTE LOGIN</li>
            </ul>
        </div>
        <div class="col-md-3 d-flex justify-content-center align-items-center" style="background-color:#c3a9ff;">
        <img src="images/c3.png" width="80%" alt="" class="">

        </div>
    </div>
 </div>

</body>
</html>