<?php
include 'config.php';
$aadhar = $_POST['aadhar_no'];
$sql = "SELECT aadhar FROM institute WHERE aadhar = {$aadhar}"; 
// echo $sql;

$result = mysqli_query($conn,$sql);
echo mysqli_num_rows($result);



?>