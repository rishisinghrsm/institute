<?php include "headerInstitute.php";

?>





<div class="container">
    <form action="certificatePay.php" method="post">
    <div class="row g p-5">
    <p class="fs-3 text-white border-bottom " style="text-shadow: 4px 4px 10px black;">ISSUE NEW CERTIFICATE</p>
        <div class="col-6">
        <label class=" text-white  mt-4">&nbsp; Student Name<span class="fs-4 text-white">*</span></label>
                <select name="id" id="" class="form-control w-75" required>
                    <option value="0" selected disabled>Select</option>
                    <?php
                    include 'config.php';

                    $sqlForStu = "SELECT * FROM `newstudent` WHERE institute = {$_SESSION['id']} AND payment = 0 AND admitCard = 1";

                    $resultForStu = mysqli_query($conn, $sqlForStu) or die('Query Fail For Category');
                    while ($rowForStu = mysqli_fetch_assoc($resultForStu)) {
                        ?>
                        <option value="<?php echo $rowForStu['id']; ?>"><span class="d-none text-success"><?php echo '<span class="d-none text-success">' . $rowForStu['payment'] . '</span>'; ?></span> <?php echo $rowForStu['name']; ?></option>
                        
                        <?php } ?>
                        <!-- <input type="hidden" name="id" value="<?php echo $rowForStu['id']; ?>"> -->
                    <?php
                    include 'config.php';

                    $sqlForStu1 = "SELECT * FROM `newstudent` WHERE institute = {$_SESSION['id']} AND payment = 0";

                    $resultForStu1 = mysqli_query($conn, $sqlForStu1) or die('Query Fail For Category');
                    while ($rowForStu1 = mysqli_fetch_assoc($resultForStu1)) {
                    ?>

                        <input type="hidden" name="payment" value="<?php echo $rowForStu1['payment']; ?>">
                    <?php } ?>
                </select>
    </div>
<div class="col-6">
<label class=" text-white  mt-4">&nbsp; Percentage<span class="fs-4 text-white">*</span></label>
<input type="number" name="percentage" required id=" " class="form-control w-75 mt-2 bg-transparent text-white " placeholder="Enter Your Institute's Name !">
</div>


<div class="12 text-center">
<input type="submit" name="submit" value="Submit !" id=" " class="form-control  w-75 mt-5 mb-5 m-auto bg-transparent text-white">

</div>
            </form>












        
    </div>
</div>


<?php include "instituteFooter.php" ?>