<?php
include "config.php";


if(isset($_POST['login'])){
    $aadhar =mysqli_real_escape_string($conn,md5($_POST['aadhar']));
    $pass = mysqli_real_escape_string($conn,md5($_POST['pass']));
    // $role = $_POST['role'];

    $sql = "SELECT * FROM `USER` WHERE `USERNAME` = '$aadhar' AND `PASSWORD` = '$pass'";
   
    $result= mysqli_query($conn,$sql) or die("Query Fail");
    
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            session_start();
            
            $_SESSION["name"] = $row['NAME'];
            $_SESSION["id"] = $row['ID'];
           
            // echo $host;
            header("Location:". $path. "dashboard.php");
            
        }
    }else{
        echo "No User Found";
    }
}else{
    echo "Login Fail";
}


?>