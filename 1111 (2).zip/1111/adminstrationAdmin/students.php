<?php
include 'header.php';

?>
<div class="container">
    <div class="row">
        <div class="col-12">

       
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for state.." class="form-control mt-5">
<table class="uk-table uk-table-hover uk-table-divider" id="myTable">
    <thead class="sticky-top ">
        <tr>
            <th>Sno.</th>
            <th>Id.</th>
            <th onclick="sortTable(1)">State ^ </th>
            <th>Name</th>
            <th>Phone</th>
            <th>Center Name</th>
            <th>Skill Name</th>
            <th >Reg No. </th>
            <th>Payment</th>
            <!-- <th>Approved ?</th> -->
            <th>Student Detail</th>
        </tr>
    </thead>
    <tbody>

    <?php
    $num = 1;
$sql = "SELECT *,newStudent.name,newStudent.id,newStudent.phone,newStudent.institute FROM newStudent 
        LEFT JOIN `institute` ON institute.id = newStudent.institute
        LEFT JOIN `state` ON state.stateId = newStudent.state
        LEFT JOIN `subskill` ON subskill.id = newStudent.course
         ORDER BY newStudent.id DESC";

$result = mysqli_query($conn,$sql) or die('fail');
while($row = mysqli_fetch_assoc($result)){



?>

  <tr uk-scrollspy="cls:uk-animation-slide-left">
    
    
    <td><?php echo $num; ?></td>
    <td><?php echo $row['id']; ?></td>
    <td id="state"><?php echo $row['stateName']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['phone']; ?></td>
    <td><?php echo $row['institutename']; ?></td>
    <td><?php echo $row['subSkillName']; ?></td>
    <td><?php echo $row['regNo']; ?></td>
    <td><?php
         if($row['payment'] == 0){
           echo 'Not Done!';
          }else if($row['payment'] == 1){
            
            echo ' Done!';
          }else{
            echo 'Error';
          }
          // echo $row['payment'];
          ?></td>
       
       <td><a href="studentDetail.php?id=<?php echo $row['id']; ?>" target="_blank">DETAIL</a></td>
       
       
      </tr>
        <?php $num++; }; ?>
    </tbody>
</table>


</div>
    </div>
</div>
<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
<script>
function sortTable(n) {
  var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
  table = document.getElementById("myTable");
  switching = true;
  //Set the sorting direction to ascending:
  dir = "asc"; 
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[n];
      y = rows[i + 1].getElementsByTagName("TD")[n];
      /*check if the two rows should switch place,
      based on the direction, asc or desc:*/
      if (dir == "asc") {
        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch= true;
          break;
        }
      } else if (dir == "desc") {
        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch = true;
          break;
        }
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
      //Each time a switch is done, increase this count by 1:
      switchcount ++;      
    } else {
      /*If no switching has been done AND the direction is "asc",
      set the direction to "desc" and run the while loop again.*/
      if (switchcount == 0 && dir == "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}
</script>
<a href="#" uk-totop uk-scroll></a>