<?php
 include 'header.php'; ?>


<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="col-4 p-4 lg rounded">
            <?php 
            $id = $_GET['id'];
            $sql = "SELECT *,institute.id FROM institute
                    left join skills on skills.id = institute.skill 
                    left join state on state.stateId = institute.state
                    WHERE institute.id = {$id}";
            
            $result = mysqli_query($conn,$sql);
            while($row = mysqli_fetch_assoc($result)){

            
            ?>
            <div class="img text-center text-white">
                <P class="fs-4 border-bottom ">OWNER </P>
                <img src="../institute-images/<?php echo $row['aadhar'] ?>/pp/<?php echo $row['pp'] ?>" alt="" style="max-width: 120px;max-height:160px">
                <P class="fs-4 border-bottom ">AADHAR / PAN </P>
                <img src="../institute-images/<?php echo $row['aadhar'] ?>/aadhar/<?php echo $row['aadharFront'] ?>" alt="">
                <br>
                <br>
                <img src="../institute-images/<?php echo $row['aadhar'] ?>/aadhar/<?php echo $row['aadharBack'] ?>" alt="">
                <P class="fs-4 border-bottom ">INSTITUTE PICTURES </P>
                <img src="../institute-images/<?php echo $row['aadhar'] ?>/<?php echo $row['img1'] ?>" alt="">
                <br>
                <br>
                <img src="../institute-images/<?php echo $row['aadhar'] ?>/<?php echo $row['img2'] ?>" alt="">
                <br>    
                <br>    
                <img src="../institute-images/<?php echo $row['aadhar'] ?>/<?php echo $row['img3'] ?>" alt="">
            </div>
        </div>
        <!-- <div class="col-1 border-end"></div> -->
        <div class="col-7 ms-1 p-4 rounded g uk-text-start">
            <P class="fs-4 border-bottom text-white">INSTITUTE DETAILS</P>
            <table class="uk-table uk-table-hover uk-table-striped bg-white fw-bold rounded">
                <tbody class="rounded">
                    <tr class="d text-capitalize" >
                        <th class="text-end">
                            
                            <p>APPROVE - &nbsp;</p>
                        </th>
                        <td>

                        <?php 
        if($row['approve'] == 'cfcd208495d565ef66e7dff9f98764da'){
            echo 'Not Approved!';
        }else if($row['approve'] == 'c4ca4238a0b923820dcc509a6f75849b'){
            
            echo ' Approved!';
        }else{
            echo 'Error';
        }
        ?>
                            
                        </td>
                    </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">

                                <p>PAYMENT - &nbsp;</p>
                            </th>
                            <td>
                            <?php 
                            // echo $row['institutePayment'];
        if($row['institutePayment'] == "0"){
            echo 'Not Paid!';
        }else if($row['institutePayment'] == "1"){
            
            echo ' Paid !';
        }else{
            echo 'Error';
        }
        ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Code - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['id'] ?>
                            </td>
                        </tr>
               
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>OWNAR NAME - &nbsp;</p>
                            </th>
                            <td class="fs-5 text-danger">
                            <?php echo $row['name'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>INSTITUTE NAME - &nbsp;</p>
                            </th>
                            <td class="fs-5 text-danger">
                            <?php echo $row['institutename'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>skill - &nbsp;</p>
                            </th>
                            <td class="fs-5 text-danger">
                            <?php echo $row['skills'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>No of Student - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['noOfStudent'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>A/C - &nbsp;</p>
                            </th>
                            <td>
                            <?php 
        if($row['airCondining'] == '0'){
            echo 'No';
        }else if($row['airCondining'] == '1'){
            
            echo ' Yes !';
        }else{
            echo 'Error';
        }
        ?>
                            <!-- <?php echo $row['airCondining'] ?> -->
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>No Of Class Room - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['noOfClassRoom'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>No Of Teacher - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['noOfTeacher'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Power Backup- &nbsp;</p>
                            </th>
                            <td>
                            <?php 
        if($row['powerBackup'] == '0'){
            echo 'No';
        }else if($row['powerBackup'] == '1'){
            
            echo ' Yes !';
        }else{
            echo 'Error';
        }
        ?>
                            <!-- <?php echo $row['powerBackup'] ?> -->
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Center Area - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['centerArea'] ?> Sq * Ft
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>state- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['stateName'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>District - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['district'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Pincode - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['pincode'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Address- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['address'] ?>
                            </td>
                        </tr>
                        <tr class="border-bottom ">
                       <th class="text-center fs-4 " class="fs-4 text-center">OWNER DETAIL</th>
                       <th class="text-end" class="fs-4 text-center"></th>

                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Name- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['name'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>father's Name- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['fname'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Aadhar Card- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['aadhar'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Phone- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['phone'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Email- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['email'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Education- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['education'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Date Of Birth- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['dob'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>Gender- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['gender'] ?>
                            </td>
                        </tr>
                       
                        <?php };?>
                    </tbody>
                </table>
                <a href="approve.php?id=<?php echo $id ?>" class="btn btn-outline-danger w-100 text-white">APPROVE</a>
       
</div>
    </div>
</div>
    