<?php
 include 'header.php'; ?>


<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="col-4 p-4 lg rounded">
            <?php 
            $id = $_GET['id'];
            $sql = "SELECT *,newStudent.id, newStudent.name, newStudent.fname, newStudent.mname, newStudent.phone, newStudent.email, newStudent.aadhar, newStudent.gender, newStudent.state, newStudent.address, newStudent.pincode, newStudent.course, newStudent.date, newStudent.yearOfAdmission, newStudent.time, newStudent.institute, newStudent.regNo, newStudent.payment, newStudent.admitCard, newStudent.img FROM newStudent 
            left join state on state.stateId = newStudent.state
            left join subSkill on subskill.id = newStudent.course
            left join certificate on certificate.studentId = newStudent.id
            left join institute on institute.id = newStudent.institute
            WHERE newStudent.id = {$id}";
            
            $result = mysqli_query($conn,$sql);
            while($row = mysqli_fetch_assoc($result)){

            
            ?>
            <div class="img text-center text-white">
                <P class="fs-4 border-bottom ">PICTURE </P>
                
                <img src="../institute-images/<?php echo $_SESSION['aadhar'] ?>/students/<?php echo $row['aadhar']."/".$row['img'] ?>" alt="" >
                <br>
                <br>
                <img src="../institute-images/<?php echo $_SESSION['aadhar'] ?>/students/<?php echo $row['aadhar']."/".$row['regNo']."_".$row['id'].".jpg" ?>" alt="" >
            </div>
        </div>
        <!-- <div class="col-1 border-end"></div> -->
        <div class="col-7 ms-1 p-4 rounded g uk-text-start">
            <P class="fs-4 border-bottom text-white">INSTITUTE DETAILS</P>
            <table class="uk-table uk-table-hover uk-table-striped bg-white fw-bold rounded">
                <tbody class="rounded">
                    
                        <tr class="d text-capitalize" >
                            <th class="text-end">

                                <p>PAYMENT - &nbsp;</p>
                            </th>
                            <td>
                            <?php 
                            // echo $row['institutePayment'];
        if($row['payment'] == "0"){
            echo 'Not Paid!';
        }else if($row['payment'] == "1"){
            
            echo ' Paid !';
        }else{
            echo 'Error';
        }
        ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>ID - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $_GET['id'] ?>
                            </td>
                        </tr>
               
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p> NAME - &nbsp;</p>
                            </th>
                            <td class="fs-5 text-danger">
                            <?php echo $row['name'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p> FATHER / HUSBAND NAME - &nbsp;</p>
                            </th>
                            <td class="fs-5 text-danger">
                            <?php echo $row['fname'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>MOTHER NAME - &nbsp;</p>
                            </th>
                            <td class="fs-5 text-danger">
                            <?php echo $row['mname'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>PHONE - &nbsp;</p>
                            </th>
                            <td class="fs-5 text-danger">
                            <?php echo $row['phone'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>skill - &nbsp;</p>
                            </th>
                            <td class="fs-5 text-danger">
                            <?php echo $row['subSkillName'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>DATE OF ADMISSION (DD-MM-YY)- &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['date'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>SESSION - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['yearOfAdmission'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>REGISTRATION NO. - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['regNo'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>CERTIFICATE NO. - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['certificateNo'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>DURATION - &nbsp;</p>
                            </th>
                            <td>
                                <?php echo $row['duration'] ?> MONTHS
                            </td>
                        </tr>
                            <tr class="d text-capitalize" >
                                <th class="text-end">
                                    
                                    <p>PERCENTAGE - &nbsp;</p>
                                </th>
                                <td>
                                <?php echo $row['percentage'] ?>%
                                </td>
                            </tr>
                            <tr class="d text-capitalize" >
                                <th class="text-end">
                                    
                                    <p>INSTITUTE - &nbsp;</p>
                                </th>
                                <td>
                                <?php echo $row['institutename'] ?>
                                </td>
                            </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>EMAIL -&nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['email'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>AADHAR - &nbsp;</p>
                            </th>
                            <td>
                           
                            <?php echo $row['aadhar'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>GENDER - &nbsp;</p>
                            </th>
                            <td>
                            <?php if($row['gender']=='m'){
                                echo "Male";
                            } else{
                                echo " Female";
                                
                            }?>
                            <!-- <?php echo $row['gender'] ?> -->
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>STATE - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['stateName'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>ADDRESS- &nbsp;</p>
                            </th>
                            <td>
                            
                            <?php echo $row['address'] ?>
                            </td>
                        </tr>
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>PINCODE - &nbsp;</p>
                            </th>
                            <td>
                            <?php echo $row['pincode'] ?> 
                            </td>
                        </tr>
                       
                        <tr class="d text-capitalize" >
                            <th class="text-end">
                                
                                <p>ADMIT CARD- &nbsp;</p>
                            </th>
                            <td>
                            <?php if($row['admitCard']==0){
                                echo "Not Downloaded";
                            } else{
                                echo " Downloaded";
                                
                            }?>
                            </td>
                        </tr>
                       
                       
                        <?php };?>
                    </tbody>
                </table>
                <!-- <a href="approve.php?id=<?php echo $id ?>" class="btn btn-outline-danger w-100 text-white">APPROVE</a> -->
       
</div>
    </div>
</div>
    