<?php
include 'config.php';
$id = $_GET['id'];
$sql = "UPDATE `institute` SET `approve`= 'c4ca4238a0b923820dcc509a6f75849b' WHERE `id` = $id;";
// echo $sql;
$updateResult = mysqli_query($conn, $sql) or die("update fail");
header('Location: ' . $path . 'Institutes.php?submit=approved');





?>