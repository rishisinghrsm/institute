<?php

$root = 'localhost';
$pass = '';
$username = 'root';
$database = 1111;

$conn = mysqli_connect($root,$username,$pass,$database) or die("Database Connect Fail !");
global $cname;
$cname = 'INDIAN INSTITUTE OF SKILLS';
$path = "";
global $stuId;



?>