<?php
include "config.php";


session_start();
// if (!isset($_SESSION['phone'])) {
//     header('Location: ' . $path . 'index.php');
// }


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <title>
        <?php
        echo $cname;
        ?>
    </title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/css/uikit.min.css" />

    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.17.0/dist/js/uikit-icons.min.js"></script>

    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Gabarito:wght@500&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">


    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        body{
            min-height: 100vh;
        }
        .name {
            font-family: "Red Hat Display", sans-serif;
        }

        .big {
            font-weight: lighter;
            font-size: 50px;
            font-family: "Red Hat Display", sans-serif;
            border-left: 5px;
            border: 5px solid;
            border-top-color: transparent;
            border-right-color: transparent;
            border-bottom-color: transparent;
        }

        .font {
            font-family: "Red Hat Display", sans-serif;

        }

        .brown {
            background-color: #d17b30;
        }

        .blue {
            background-color: #01789e;
        }

        .purple {
            background-color: #c3a9ff;
        }

        .bb-t {
            color: wheat;
        }

        .brown-t {
            color: #d17b30;
        }

        .blue-t {
            color: #01789e;
        }

        .purple-t {
            color: #c3a9ff;
        }

        ul {

          
        }
li{

    list-style-type:none;
}
        .navv li {
            text-decoration: none;
            /* text-decoration-color: transparent; */
            list-style-type:none;
            margin-top: 10px;
            /* border-bottom: 1px solid white; */
        }

        .activee{
            /* background-color: #d17b30; */
            /* color: red; */
            font-weight: 400;
        }
        #dis{
            background-color: transparent;
            border: 0px;
        }
        #dis:focus {
  border: 3px solid tomato;
  transform: scale(1.2);
}

.lg{
    background-color: #017e7e;
}
.lg-t{
    color: #017e7e;
}

.g{
    background-color: #045d5d;
}
.g-t{
    color: #045d5d;
}
.g-tt{
    color: #99d9d9;
}

    </style>
</head>

<body>

    <div class=" container-fluid lg text-white">
    <div class="row">
        <div class="col-7 text-end">
        <?php echo $cname ?> 

        </div>
        <div class="col-5 text-end">
        <a href="logout.php" class="text-white  ">Hello <?php echo $_SESSION['name'] ?>, LOGOUT</a>

        </div>
    </div>    

</div>


            <?php
            
          
            $page = basename($_SERVER['PHP_SELF']);
            echo $page;

            if($page == "getCertificate.php"){
                echo "<div class='text-center fs-4  p-2 rounded shadow-lg lg text-white'>New Certificate</div>";
            }else if($page == "newStudent.php"){
                echo "<div class='text-center fs-4  p-2 rounded shadow-lg lg text-white'>Add New Student</div>";

            }else if($page == "showCertificate.php"){
                echo "<div class='text-center fs-4  p-2 rounded shadow-lg lg text-white'>All Certificate</div>";

            }
            ?>


<nav class="navbar g fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-white" href="#"><?php echo $cname ?></a>
    <button class="navbar-toggler bg-white" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon "></span>
    </button>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasNavbarLabel"><?php echo $cname ?></h5>
        <button type="button" class="btn-close " data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="dashboard.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Institutes.php">Institutes</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="students.php">Students</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Institutes.php">Institutes</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Dropdown
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Action</a></li>
              <li><a class="dropdown-item" href="#">Another action</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="#">Something else here</a></li>
            </ul>
          </li>
        </ul>
        <form class="d-flex mt-3" role="search">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
      </div>
    </div>
  </div>
</nav>

<br><br>