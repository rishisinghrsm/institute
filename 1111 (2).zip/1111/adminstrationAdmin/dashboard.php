<?php include 'header.php' ?>
<div class="container">
    <div class="row">
        <div class="col-md-4 rounded-4 border text-center lg g-t uk-card uk-card-default uk-card-body -shake uk-animation">
            <h3 class="text-white ">TOTAL STUDENT</h3>
        <?php 
            $num1 = 0;
            $sql1 = "SELECT id FROM newStudent";
            $result1 = mysqli_query($conn,$sql1);
            while($row2 = mysqli_fetch_assoc($result1)){
                $num1 = $num1 + 1;
            }
            echo "<div class='num1 uk-heading-xlarge  text-white' akhi='{$num1}'>0</div>";
            ?>

            <script>
                const counters = document.querySelectorAll('.num1');
const speed = 200;

counters.forEach( counter => {
   const animate = () => {
      const value = +counter.getAttribute('akhi');
      const data = +counter.innerText;
     
      const time = value / speed;
     if(data < value) {
          counter.innerText = Math.ceil(data + time);
          setTimeout(animate, 1);
        }else{
          counter.innerText = value;
        }
     
   }
   
   animate();
});



            </script>
        </div>
        <div class="col-md-4 rounded-4 border text-center bg-success g-t uk-card uk-card-default uk-card-body -slide-top ">
            <h3 class="text-white ">TOTAL INSTITUTE</h3>
        <?php 
            $num2 = 0;
            $sql2 = "SELECT * FROM `institute`";
            $result2 = mysqli_query($conn,$sql2);
            while($row2 = mysqli_fetch_assoc($result2)){
                $num2 = $num2 + 1;
            }
            echo "<div class='num2 uk-heading-xlarge  text-white' akhi='{$num2}'>0</div>";
            ?>

            <script>
                const counters1 = document.querySelectorAll('.num2');
const speed1 = 200;

counters1.forEach( counter => {
   const animate = () => {
      const value = +counter.getAttribute('akhi');
      const data = +counter.innerText;
     
      const time = value / speed1;
     if(data < value) {
          counter.innerText = Math.ceil(data + time);
          setTimeout(animate, 1);
        }else{
          counter.innerText = value;
        }
     
   }
   
   animate();
});



            </script>
        </div>
        <div class="col-md-4 rounded-4 border text-center  g g-t uk-card uk-card-default uk-card-body -slide-right ">
            <h3 class="text-white ">TOTAL CERTIFICATE ISSUED </h3>
        <?php 
            $num5 = 0;
            $sql5 = "SELECT * FROM `certificate`";
            $result5 = mysqli_query($conn,$sql5);
            while($row5 = mysqli_fetch_assoc($result5)){
                

                    $num5 = $num5 + 1;
                
            }
            echo "<div class='num5 uk-heading-xlarge  text-white' akhi='{$num5}'>0</div>";
            ?>

            <script>
                const counters4 = document.querySelectorAll('.num5');
const speed4 = 200;

counters4.forEach( counter => {
   const animate = () => {
      const value = +counter.getAttribute('akhi');
      const data = +counter.innerText;
     
      const time = value / speed4;
     if(data < value) {
          counter.innerText = Math.ceil(data + time);
          setTimeout(animate, 1);
        }else{
          counter.innerText = value;
        }
     
   }
   
   animate();
});



            </script>
        </div>
        <div class="col-md-4 rounded-4 border text-center bg-info g-t uk-card uk-card-default uk-card-body -slide-left ">
            <h3 class="text-white ">TOTAL NO OF STATE COVERED</h3>
        <?php 
            $num3 = 0;
            $sql3 = "SELECT * FROM `state`";
            $result3 = mysqli_query($conn,$sql3);
            while($row3 = mysqli_fetch_assoc($result3)){
                if($row3['noOfInstituteRegistered'] > 0){

                    $num3 = $num3 + 1;
                }
            }
            echo "<div class='num3 uk-heading-xlarge  text-white' akhi='{$num3}'>0</div>";
            ?>

            <script>
                const counters2 = document.querySelectorAll('.num3');
const speed2 = 200;

counters2.forEach( counter => {
   const animate = () => {
      const value = +counter.getAttribute('akhi');
      const data = +counter.innerText;
     
      const time = value / speed2;
     if(data < value) {
          counter.innerText = Math.ceil(data + time);
          setTimeout(animate, 1);
        }else{
          counter.innerText = value;
        }
     
   }
   
   animate();
});



            </script>
        </div>
        <div class="col-md-4 rounded-4 border text-center bg-warning g-t uk-card uk-card-default uk-card-body -slide-bottom ">
            <h3 class="text-white ">TOTAL SKILLS </h3>
        <?php 
            $num4 = 0;
            $sql4 = "SELECT * FROM `skills`";
            $result4 = mysqli_query($conn,$sql4);
            while($row4 = mysqli_fetch_assoc($result4)){
                

                    $num4 = $num4 + 1;
                
            }
            echo "<div class='num4 uk-heading-xlarge  text-white' akhi='{$num4}'>0</div>";
            ?>

            <script>
                const counters3 = document.querySelectorAll('.num4');
const speed3 = 200;

counters3.forEach( counter => {
   const animate = () => {
      const value = +counter.getAttribute('akhi');
      const data = +counter.innerText;
     
      const time = value / speed3;
     if(data < value) {
          counter.innerText = Math.ceil(data + time);
          setTimeout(animate, 1);
        }else{
          counter.innerText = value;
        }
     
   }
   
   animate();
});



            </script>
        </div>
       
        <div class="col-md-4 rounded-4"></div>
        <div class="col-md-4 rounded-4"></div>
        <div class="col-md-4 rounded-4"></div>
        <div class="col-md-4 rounded-4"></div>
        <div class="col-md-4 rounded-4"></div>
        <div class="col-md-4 rounded-4"></div>
    </div>
</div>