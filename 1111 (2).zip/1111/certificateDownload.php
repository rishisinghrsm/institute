<?php
include "headerInstitute.php";
include "config.php";

$id = $_GET['id'];
$sql = "SELECT * FROM certificate WHERE id = $id";
$result = mysqli_query($conn,$sql) or die("dead");
while($row = mysqli_fetch_assoc($result)){

    // print_r($row);
    if($row['payment'] == 0){
        
        header("Locaton ".$path."allstudent.php");
    }else{
        header("Locaton ".$path."certificateDownloadNext.php");
    }

}

?>