<?php
include_once 'header.php';
if (isset($_POST['submit'])) {
    include 'config.php';
    $no = mysqli_escape_string($conn, $_POST['no']);


    $sql  = "SELECT *,certificateNo,newStudent.institute, newStudent.payment FROM newstudent 
                    LEFT JOIN certificate ON certificate.studentId = newStudent.id
                    LEFT JOIN state ON state.stateId = newStudent.state
                    LEFT JOIN subSkill ON subSkill.id = newStudent.course
                    LEFT JOIN institute ON institute.id = newStudent.institute
                     WHERE newStudent.regNo = '{$no}' OR certificate.certificateNo = '{$no}'";
    //  echo $sql;
    $result = mysqli_query($conn, $sql) or die('dead');
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            
            if (($row['certificateNo']) != $no OR $row['regNo'] != $no) {
            echo '<script>window.location.replace("document.php?submit=due");</script>';

            }
            //  echo $row['regNo'];
            //  echo $row['certificateNo'];
            if ($row['payment'] == 1) {
                
                // if ($row['regNo'] = $no || $row['certificateNo'] = $no) {

?>



                <div class="container-fluid my-5 d-flex justify-content-center" style="background-image: url(images/bg.png);">
                    <div class="row p-5 shadow-lg" style="backdrop-filter: blur(15px);">
                        <div class="col-md-4 sticky-md-top">
                            <img src="<?php echo 'student-images/' . $row['img'] ?>" alt="" class=" border rounded-circle" style="max-width: 380px;min-width:450px;min-height: 450px;max-height:300px;">
                        </div>
                        <div class="col-md-1"></div>
                        <div class="col-md-7">
                            <label class="lg-t" for="">Name :- </label>
                            <span class="fs-1 g-t text-capitalize">&nbsp;<?php echo $row['name'] ?></span><br>
                            <label class="lg-t" for="">Father's Name :- </label>
                            <span class="fs-3 g-t text-capitalize">&nbsp;<?php echo $row['fname'] ?></span><br>
                            <label class="lg-t" for="">Mother's Name :- </label>
                            <span class="fs-3 g-t text-capitalize">&nbsp;<?php echo $row['mname'] ?></span><br>
                            <label class="lg-t" for="">State :- </label>
                            <span class="fs-3 g-t text-capitalize">&nbsp;<?php echo $row['stateName'] ?></span><br>
                            <label class="lg-t" for="">Address :- </label>
                            <span class="fs-3 g-t text-capitalize">&nbsp;<?php echo $row['address'] ?></span><br>
                            <label class="lg-t" for="">Pincode :- </label>
                            <span class="fs-3 g-t text-capitalize">&nbsp;<?php echo $row['pincode'] ?></span><br>
                            <label class="lg-t" for="">Course :- </label>
                            <span class="fs-2 g-t fw-5 text-capitalize">&nbsp;<?php echo $row['subSkillName'] ?></span><br>
                            <label class="lg-t" for="">Date Of Registration (dd-mm-yy) :- </label>
                            <span class="fs-2 g-t fw-5 text-capitalize">&nbsp;<?php echo $row['date'] ?></span><br>
                            <label class="lg-t" for="">Institute :- </label>
                            <span class="fs-2 g-t fw-5 text-capitalize">&nbsp;<?php echo $row['institutename'] ?></span><br>
                            <label class="lg-t" for="">Registration No :- </label>
                            <span class="fs-2 g-t fw-5 text-capitalize">&nbsp;<?php echo $row['regNo'] ?></span><br>
                            <label class="lg-t" for="">Certificate No :- </label>
                            <span class="fs-2 g-t fw-5 text-capitalize">&nbsp;<?php echo $row['certificateNo'] ?></span><br>

                            <a href="#" class="btn btn-outline-success w-100 mt-5">Download Again </a>
                        </div>
                    </div>
                </div>
<?php



            // } else {
            //     // echo 'error';
            //     echo '<script>window.location.replace("document.php?submit=wrong");</script>';
            //     // header("Location: " . $path. "document.php?submit=wrong");
            // }
        } else {
            echo '<script>window.location.replace("document.php?submit=due");</script>';
            // header("Location: " . $path. "document.php?submit=due");
        }
    }
}else{
    echo '<script>window.location.replace("document.php?submit=wrong");</script>';

}
}
?>

<script>

   
</script>